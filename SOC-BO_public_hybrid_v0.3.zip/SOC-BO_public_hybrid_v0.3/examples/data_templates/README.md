# Hydraulic-fracturing observation template

Required columns:

```text
point_id,borehole_id,sh_max_mpa,sh_min_mpa,sv_mpa,sh_azimuth_deg,stress_weight,orientation_weight
```

- `SH`, `Sh`, and `Sv` are conventional positive compression magnitudes in MPa.
- `SH` must be greater than or equal to `Sh`.
- azimuth is geographic, clockwise from North, with 180° axial periodicity.
- weights are non-negative and user specified.
- `point_id` must be unique and must match the private FLAC3D point mapping.

The MATLAB loader transforms the field magnitudes to native FLAC3D signed
components in Pa. The input file must not contain pre-negated stress magnitudes.
