# Persistent MATLAB–FLAC3D file-queue protocol

## State machine

```text
queued -> running -> completed
                  -> failed
                  -> cancelled
```

A UUID task occupies exactly one state directory. Publication and state changes
use same-filesystem directory moves. The exchange root must therefore reside on
one reliable local filesystem.

## Request files

Each queued task contains:

- `request.json`: immutable schema, parameter names/units/values, point IDs,
  loading elevations, coordinate metadata, model hash, and output convention;
- `parameters.csv`: human-readable six-parameter record;
- `READY`: publication marker.

The request requires the exact parameter order, FLAC-native sign declaration,
Pa output, and tensor component order.

## Worker heartbeat and lease

Each worker writes `workers/worker_<uuid>.json`. MATLAB refuses to publish a
candidate unless a recent compatible heartbeat has the expected worker version,
FLAC3D version prefix, and `model_config_hash`.

After claim, the worker refreshes `running/<run_id>/lease.json` from a background
thread while FLAC3D is solving. An expired lease is requeued at startup unless
the maximum attempt count is reached.

## Output files

A successful terminal directory contains:

- `stress.csv` with `point_id,sxx_pa,syy_pa,szz_pa,sxy_pa,syz_pa,sxz_pa`;
- `result.json` with run ID, convergence state, cycles/metric when supplied,
  elapsed time, model hash, stress conventions, and SHA-256 digest.

MATLAB verifies the result identity, schema, worker version, model hash,
convergence flag, tensor convention, checksum, exact point-ID set, and finite
values. Rows are reordered by `point_id`, never by implicit file order.

## Cancellation and recovery

At timeout MATLAB writes `CANCEL` in the queued or running task directory and
waits for a terminal acknowledgement. A private FLAC3D adapter should solve in bounded chunks, call the supplied `keepalive()` callback to renew the lease, and query the cancellation callback between chunks. If the solver cannot be interrupted safely, cancellation is enforced
before accepting the result.

Failed, cancelled, and completed tasks are retained by default for audit and
restart diagnostics.
