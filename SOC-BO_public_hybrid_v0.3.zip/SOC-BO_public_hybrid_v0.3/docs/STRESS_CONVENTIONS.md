# Stress, unit, component, and coordinate conventions

## 1. Native FLAC3D tensor convention

All internal and exchanged tensor stresses follow the FLAC3D convention:

- tension is positive;
- compression is negative;
- output unit is Pa;
- component order is `[sxx, syy, szz, sxy, syz, sxz]`.

The code never multiplies the complete FLAC3D tensor by `-1` and never changes
an individual shear-component sign. Converting Pa to MPa for reporting is a
positive scale factor only.

## 2. Hydraulic-fracturing input convention

The input columns `sh_max_mpa`, `sh_min_mpa`, and `sv_mpa` are conventional
positive compression magnitudes. They are measurement magnitudes, not signed
tensor components. For geographic SH unit vector `v`, the horizontal tensor in
FLAC3D convention is

\[
\boldsymbol\sigma_h^{geo}
=-S_h\mathbf I-(S_H-S_h)\mathbf v\mathbf v^T.
\]

The vertical tensor component is `sigma_zz = -Sv` before unit conversion.

## 3. Horizontal principal direction under FLAC3D signs

For

\[
\boldsymbol\sigma_h=
\begin{bmatrix}\sigma_{xx}&\sigma_{xy}\\
\sigma_{xy}&\sigma_{yy}\end{bmatrix},
\]

ascending eigenvalues satisfy `lambda_1 <= lambda_2`. The most compressive
horizontal direction is the eigenvector of `lambda_1`; field-reporting
magnitudes are

\[
S_H=-\lambda_1,\qquad S_h=-\lambda_2.
\]

## 4. Coordinates and azimuth

Geographic azimuth is clockwise from North with 180° axial periodicity. If
model +X has azimuth `alpha`, the right-handed model +Y axis has azimuth
`alpha-90°`, with +Z upward. The same transformation is used for observations
and simulated tensors.
