# v0.3 implementation audit

## Resolved high-risk issues

1. **Stress sign ambiguity** — all internal/exchanged tensors now use FLAC3D's
   native tension-positive/compression-negative convention. HF magnitudes are
   converted once at the observation boundary.
2. **Wrong SH eigenvalue under native signs** — SH direction now uses the
   smallest horizontal eigenvalue.
3. **Implicit point order** — every solver row carries `point_id`; MATLAB joins
   explicitly and rejects missing, duplicate, or extra IDs.
4. **Stale output reuse** — each candidate has an immutable UUID task directory
   and terminal result identity.
5. **Partial writes** — files and task publication use temporary paths and
   same-filesystem replacement.
6. **Worker absence/crash** — MATLAB requires a fresh compatible heartbeat;
   running tasks carry renewable leases and can be recovered after expiry.
7. **Unconverged results** — the adapter must return convergence status and the
   worker rejects false status.
8. **Silent configuration mismatch** — MATLAB and FLAC3D require the same
   SHA-256 model/config identifier.
9. **Corrupted output** — `stress.csv` is verified against its SHA-256 digest.
10. **Timeout without cancellation** — MATLAB writes a cancellation marker and
    waits for terminal acknowledgement while preserving task files.

## Validation completed in the preparation environment

- Python source compilation;
- 15 solver-independent Python tests covering signs, units, transformations,
  loading profiles, protocol schema, checksums, queue completion, and
  cancellation.

## Validation still required on the author's workstation

- MATLAB R2022b execution of `tests/matlab/run_all_tests.m`;
- FLAC3D 7.0 private adapter implementation;
- one end-to-end private queue run;
- visual/numerical confirmation that each confidential face group receives the
  intended normal and shear traction sign;
- confirmation of the selected FLAC3D equilibrium criterion and extraction
  locations.
