# Private MATLAB–FLAC3D end-to-end validation checklist

Complete these checks before tagging a public release.

1. Run `tests/matlab/run_all_tests.m` in MATLAB R2022b.
2. Compute a private model/config hash from the base save file, adapter,
   boundary manifest, and point map; use the same value in MATLAB and Python.
3. Start the FLAC3D 7.0 worker and confirm a fresh compatible heartbeat appears
   in `exchange/workers/`.
4. Submit one known six-parameter candidate outside the full BO loop.
5. In FLAC3D, list or inspect the applied face tractions and verify:
   - compressive normal components are negative;
   - `SXY` has the requested native tensor sign;
   - the X/Y linear profiles attain the configured top and bottom values;
   - gravity is `(0,0,-G)`.
6. Verify the adapter extracts `[sxx,syy,szz,sxy,syz,sxz]` in Pa without sign
   reversal and maps each row to the correct `point_id`.
7. Confirm `result.json` records `converged=true` only after the selected
   equilibrium criterion is satisfied.
8. Independently calculate SH/Sh and azimuth at at least two points from the
   extracted horizontal tensor and compare with MATLAB output.
9. Trigger one intentional adapter error and confirm the task moves to `failed/`
   with a readable traceback.
10. Trigger one cancellation/timeout test using a short solve chunk and confirm
    the task moves to `cancelled/` without a ghost `running/` directory.
11. Restart the worker with one expired synthetic lease and confirm finite
    recovery behavior.
12. Run a short SOC-BO sequence, stop/restart MATLAB from the checkpoint, and
    confirm the candidate history remains consistent.
