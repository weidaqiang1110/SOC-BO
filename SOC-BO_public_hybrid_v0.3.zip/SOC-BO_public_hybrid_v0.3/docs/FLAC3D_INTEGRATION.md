# FLAC3D 7.0 integration

## Public/private separation

The public package contains the queue worker, schema, loading equations,
stress/azimuth utilities, and adapter template. The private adapter contains the
restore path, boundary groups, material setup, solve criterion, and point
mapping.

## Native stress contract

The private adapter must return a `ForwardResult` with native FLAC3D total
stresses in Pa and component order

```text
[sxx, syy, szz, sxy, syz, sxz]
```

Compression remains negative. Do not multiply the tensor by `-1`; do not change
only `sxy`; do not reorder `syz` and `sxz`.

## Applying the six parameters

- apply gravity as `(0,0,-G)`;
- apply X and Y native signed uniform-plus-linear normal profiles;
- apply one native signed `SXY` tensor shear component;
- use the exact private boundary groups represented in the manuscript model.

The project adapter receives `z_top_m` and `z_bottom_m` from the immutable task
request, avoiding duplicate elevation definitions.

## Convergence

`solve_and_verify` must return `converged=True` only when the project-selected
criterion is met. The public worker rejects unconverged results. Solve in bounded cycle chunks and call the supplied `keepalive()` callback so the lease is renewed even if the FLAC3D solve does not release the Python GIL; check cancellation between chunks.

## Model/config hash

The private adapter returns a SHA-256 identifier derived from the restored model
and every private item that changes the forward map, including loading groups,
material configuration, and point mapping. MATLAB requires the same hash before
submitting a candidate and again when reading the result.
