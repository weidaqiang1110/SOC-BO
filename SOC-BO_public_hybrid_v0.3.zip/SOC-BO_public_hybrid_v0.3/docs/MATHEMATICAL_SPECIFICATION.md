# Mathematical specification implemented in v0.3

## 1. Inverse vector and native signs

```text
x = [G, SX_uniform, SY_uniform, SX_linear, SY_linear, SXY]
```

`G>0` is applied as gravity `(0,0,-G)`. The five stress parameters use MPa and
FLAC3D's native sign convention. Compressive normal terms are negative.

## 2. Linear horizontal boundary profiles

For `z_top > z_bottom`, define

\[
\xi(z)=\frac{z_{top}-z}{z_{top}-z_{bottom}},
\]

\[
\sigma_X(z)=S_X^U+S_X^T\xi(z),\qquad
\sigma_Y(z)=S_Y^U+S_Y^T\xi(z).
\]

A negative `S_X^T` or `S_Y^T` produces increasing compression with depth. For a
FLAC3D representation `base + gradient_z*z` in Pa,

\[
\text{base}=10^6\left(S^U+S^T\frac{z_{top}}{z_{top}-z_{bottom}}\right),
\qquad
\text{gradient}_z=-10^6\frac{S^T}{z_{top}-z_{bottom}}.
\]

No sign conversion is applied.

## 3. HF observations and coordinate transformation

Field `SH`, `Sh`, and `Sv` are positive compression magnitudes in MPa. If model
+X has geographic azimuth `alpha`, the model basis in geographic East–North
coordinates is

\[
\mathbf Q=\begin{bmatrix}
\sin\alpha&-\cos\alpha\\
\cos\alpha& \sin\alpha
\end{bmatrix}.
\]

With `v=[sin(beta_H),cos(beta_H)]^T`, the native signed horizontal tensor is

\[
\boldsymbol\sigma_h^{geo}
=-S_h\mathbf I-(S_H-S_h)\mathbf v\mathbf v^T,
\qquad
\boldsymbol\sigma_h^{model}=\mathbf Q^T
\boldsymbol\sigma_h^{geo}\mathbf Q.
\]

The objective vector in Pa is

\[
\mathbf y_i=[\sigma_{xx},\sigma_{yy},\sigma_{xy},\sigma_{zz}]^T.
\]

## 4. Point-normalized objective

\[
J=\frac{1}{\sum_i w_i^{(s)}}\sum_iw_i^{(s)}
\frac{\|\mathbf y_i^{sim}-\mathbf y_i^{obs}\|_2}
{\|\mathbf y_i^{obs}\|_2+\eta_{Pa}}.
\]

Both tensors use native signs and Pa. The user supplies non-negative point
weights and a positive stabilizer in Pa.

## 5. SH azimuth and constraints

The most compressive horizontal direction is the eigenvector associated with
the smallest eigenvalue of the native signed horizontal tensor. Signed axial
difference is

\[
\Delta\beta_i=\operatorname{mod}(\beta_i^{sim}-\beta_i^{obs}+90^\circ,
180^\circ)-90^\circ.
\]

For borehole `b`, optional orientation weights give

\[
RMSE_{\beta,b}=\sqrt{\frac{\sum_{i\in b}w_i^{(o)}\Delta\beta_i^2}
{\sum_{i\in b}w_i^{(o)}}},\qquad
\overline{\Delta\beta}_b=\frac{\sum_{i\in b}w_i^{(o)}\Delta\beta_i}
{\sum_{i\in b}w_i^{(o)}}.
\]

Only RMSE is used as a non-cancelling feasibility constraint.

## 6. Constraint schedule and acquisition

\[
\tau_b(k)=\tau_{b,f}+(\tau_{b,0}-\tau_{b,f})\exp(-\rho p_k),
\qquad p_k=\frac{k-1}{N_{BO}-1}.
\]

For independent constraint GPs,

\[
PoF(\mathbf x)=\prod_b\Phi\left(\frac{\tau_b-\mu_b(\mathbf x)}
{s_b(\mathbf x)}\right),\qquad
a(\mathbf x)=EI(\mathbf x)PoF(\mathbf x)^\beta.
\]

The acquisition is maximized with MATLAB `particleswarm`.
