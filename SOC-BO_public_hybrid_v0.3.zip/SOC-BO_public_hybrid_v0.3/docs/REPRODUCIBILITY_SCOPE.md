# Reproducibility scope

This release provides algorithmic and interface reproducibility for the hybrid
MATLAB R2022b + FLAC3D 7.0 SOC-BO workflow. It exposes the six-parameter
contract, HF tensor transformation, objective, signed azimuth constraints,
GP/PoF/cEI logic, particle-swarm acquisition optimization, checkpointing, and a
persistent auditable solver queue.

The confidential engineering model and original field data are not included.
Consequently, the repository cannot reproduce the published project-specific
numerical values by itself. A private user must supply the model, boundary
groups, loading elevations, model-X azimuth, observation-point mapping, field
measurements, weights, thresholds, and model/config hash.

Public tests establish solver-independent mathematics and protocol behavior.
They do not replace a licensed private end-to-end test in MATLAB R2022b and
FLAC3D 7.0.
