# License selection required before public release

Do not publish this repository without an approved software license.

Recommended options for discussion with the authors' institution and project owner:

- BSD 3-Clause License
- MIT License
- GPL-3.0 License

The selected license must cover only author-owned code. FLAC3D, MATLAB, and third-party source code must not be redistributed.
