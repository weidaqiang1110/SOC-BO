function results = main_socbo(config_function)
%MAIN_SOCBO Run the manuscript-matched hybrid SOC-BO workflow.
%
% Example:
%   addpath('matlab');
%   results = main_socbo(@project_config_private);

if nargin<1
    error('SOCBO:ConfigRequired','Pass a function handle returning the private project config.');
end
cfg = config_function();
socbo.validate_config(cfg);
rng(cfg.random_seed,'twister');
if ~isfolder(cfg.output_dir), mkdir(cfg.output_dir); end
obs = socbo.load_observations(cfg);

d = 6; nb = obs.n_boreholes; total = cfg.n_init+cfg.n_iter;
if cfg.resume && isfile(cfg.checkpoint_file)
    state = load(cfg.checkpoint_file);
    X = state.X; y_obj = state.y_obj; y_cons = state.y_cons;
    signed_mean = state.signed_mean; n_evaluated = state.n_evaluated;
    assert(isequal(size(X),[total,d]),'SOCBO:CheckpointShape', ...
        'Checkpoint dimensions do not match the current configuration.');
else
    X = nan(total,d);
    if ~isempty(cfg.initial_design_file)
        X0 = readmatrix(cfg.initial_design_file);
        assert(isequal(size(X0),[cfg.n_init,d]),'SOCBO:InitialDesignSize', ...
            'Initial design must be n_init-by-6.');
        assert(all(isfinite(X0),'all'),'SOCBO:InitialDesignFinite', ...
            'Initial design contains NaN or Inf.');
        assert(all(X0>=cfg.bounds(1,:) & X0<=cfg.bounds(2,:),'all'), ...
            'SOCBO:InitialDesignBounds','Initial design violates parameter bounds.');
    else
        U = lhsdesign(cfg.n_init,d,'criterion','maximin','iterations',50);
        X0 = cfg.bounds(1,:)+U.*(cfg.bounds(2,:)-cfg.bounds(1,:));
    end
    X(1:cfg.n_init,:) = X0;
    y_obj = nan(total,1); y_cons = nan(total,nb); signed_mean = nan(total,nb);
    n_evaluated = 0;
    save_checkpoint();
end

% Complete any interrupted initial design safely.
for i = n_evaluated+1:cfg.n_init
    fprintf('Initial evaluation %d/%d\n',i,cfg.n_init);
    r = socbo.evaluate_candidate(X(i,:),obs,cfg,i);
    record_result(i,r);
    n_evaluated = i;
    save_checkpoint();
end

% Continue BO from the exact number of completed evaluations.
first_bo = max(1,n_evaluated-cfg.n_init+1);
for k = first_bo:cfg.n_iter
    n_eval = cfg.n_init+k-1;
    if n_evaluated>=n_eval+1, continue; end
    assert(n_evaluated==n_eval,'SOCBO:CheckpointSequence', ...
        'Checkpoint evaluation count is inconsistent with the BO iteration.');
    tol = socbo.current_tolerance(cfg,k);
    beta = socbo.current_beta(cfg,k);
    [gp_obj,gp_cons] = socbo.fit_gp_models(X(1:n_eval,:),y_obj(1:n_eval), ...
        y_cons(1:n_eval,:),cfg);
    [y_best,~,has_feasible] = socbo.select_incumbent(y_obj(1:n_eval), ...
        y_cons(1:n_eval,:),tol);
    [x_new,acq_info] = socbo.optimize_acquisition(gp_obj,gp_cons,tol,beta,y_best,cfg);
    X(n_eval+1,:) = x_new;
    r = socbo.evaluate_candidate(x_new,obs,cfg,n_eval+1);
    record_result(n_eval+1,r);
    n_evaluated = n_eval+1;
    save_checkpoint();
    fprintf('BO %d/%d | prior feasible=%d | acquisition=%.6g | J=%.6g | RMSE=', ...
        k,cfg.n_iter,has_feasible,acq_info.score,r.objective);
    fprintf(' %.2f',r.orientation.rmse_deg); fprintf('\n');
end

valid = 1:n_evaluated;
final_tol = cfg.constraints.final_tolerance_deg;
[y_best,best_index,has_feasible] = socbo.select_incumbent(y_obj(valid),y_cons(valid,:),final_tol);
results.X = X(valid,:);
results.objective = y_obj(valid);
results.orientation_rmse_deg = y_cons(valid,:);
results.orientation_signed_mean_deg = signed_mean(valid,:);
results.best_index = best_index;
results.best_objective = y_best;
results.has_final_feasible_solution = has_feasible;
results.best_parameters = X(best_index,:);
results.parameter_names = cfg.parameter_names;
save(fullfile(cfg.output_dir,'socbo_results.mat'),'results','cfg');
write_history();

    function record_result(index,r)
        y_obj(index) = r.objective;
        y_cons(index,:) = r.orientation.rmse_deg;
        signed_mean(index,:) = r.orientation.signed_mean_deg;
    end

    function save_checkpoint()
        save(cfg.checkpoint_file,'X','y_obj','y_cons','signed_mean','n_evaluated','cfg','-v7.3');
    end

    function write_history()
        names = matlab.lang.makeValidName(cfg.parameter_names);
        T = array2table(results.X,'VariableNames',names);
        T.objective = results.objective;
        for jj = 1:nb
            id = matlab.lang.makeValidName(char(obs.borehole_name(jj)));
            T.(['rmse_',id,'_deg']) = results.orientation_rmse_deg(:,jj);
            T.(['signed_mean_',id,'_deg']) = results.orientation_signed_mean_deg(:,jj);
        end
        writetable(T,fullfile(cfg.output_dir,'optimization_history.csv'));
    end
end
