function cfg = project_config_template()
%PROJECT_CONFIG_TEMPLATE Configure the six-parameter SOC-BO v0.3 workflow.
%
% Copy this file to a private project configuration and replace each value
% marked PROJECT-SPECIFIC. The inverse vector has fixed order
%
%   x = [G, SX_uniform, SY_uniform, SX_linear, SY_linear, SXY]
%
% G is a positive magnitude in m/s^2. All five stress parameters use MPa and
% FLAC3D's native tensor convention: tension positive, compression negative.
% Therefore compressive normal terms and downward compression increments are
% normally negative. SXY is a signed tensor shear component.

cfg.software.matlab = 'R2022b';
cfg.software.flac3d = '7.0';
cfg.code_version = '0.3.0';

cfg.random_seed = 1;
cfg.n_init = 20;
cfg.n_iter = 80;

cfg.parameter_names = {'G','SX_uniform','SY_uniform','SX_linear','SY_linear','SXY'};
cfg.parameter_units = {'m/s2','MPa','MPa','MPa','MPa','MPa'};
cfg.stress_sign_convention = 'tension_positive_compression_negative';
% PROJECT-SPECIFIC examples only. Lower bounds must be numerically smaller.
cfg.bounds = [ ...
     8.0,-16.0,-15.0,-22.0,-16.0,-1.9; ...
    11.0, -8.0, -3.0, -4.0, -1.0, 1.9];
% Optional guard for this geostress application. Set false only if tensile
% far-field normal terms are intentionally permitted.
cfg.loading.require_compressive_normal_bounds = true;

% Field inputs are conventional positive compression magnitudes in MPa.
% The loader transforms them into native FLAC3D tensor components in Pa.
cfg.observation.hf_file = 'PRIVATE_PATH/hf_observations.csv';
cfg.observation.eta_pa = 1.0; % positive user-selected stabilizer, in Pa

% Geographic azimuth of model +X, clockwise from North. The model system is
% right-handed with +Z upward and +Y at alpha-90 degrees.
cfg.coordinates.model_x_azimuth_deg = NaN; % PROJECT-SPECIFIC

cfg.constraints.borehole_ids = ["BH01","BH02","BH03","BH04","BH05"];
cfg.constraints.final_tolerance_deg = [15,15,15,15,20]; % update to manuscript
cfg.constraints.initial_tolerance_deg = [15,15,15,15,20];
cfg.constraints.relaxation.type = 'exponential';
cfg.constraints.relaxation.rho = 5.0;
cfg.constraints.use_orientation_weights = true;

cfg.acquisition.beta_start = 0.30;
cfg.acquisition.beta_end = 1.00;
cfg.acquisition.anneal_slope = 10.0;
cfg.acquisition.xi = 0.0;
cfg.acquisition.min_predictive_sd = 1.0e-12;
cfg.acquisition.probability_floor = 1.0e-300;
cfg.acquisition.optimizer = 'particleswarm';
cfg.acquisition.swarm_size = 100;
cfg.acquisition.max_iterations = 50;
cfg.acquisition.max_stall_iterations = 20;
cfg.acquisition.function_tolerance = 1.0e-8;
cfg.acquisition.use_parallel = false;

cfg.gp.kernel = 'ardmatern52';
cfg.gp.basis = 'none';
cfg.gp.standardize = true;
cfg.gp.sigma_lower_bound = 1.0e-6;

% Native signed linear profiles:
% sigma_X(z)=SX_uniform+SX_linear*(z_top-z)/(z_top-z_bottom),
% and similarly for Y. A negative SX_linear/SY_linear increases compression
% downward. Exact elevations must match Fig. 6(b,d) and the private model.
cfg.loading.linear_profile.z_top = NaN;    % m, PROJECT-SPECIFIC
cfg.loading.linear_profile.z_bottom = NaN; % m, PROJECT-SPECIFIC
cfg.loading.linear_profile.clip = true;

cfg.initial_design_file = '';

% Persistent local file queue. Keep this on one local filesystem; avoid cloud-
% synchronized folders and unstable network shares because atomic directory
% moves and leases are part of the protocol.
cfg.forward.mode = 'flac3d_persistent_file_queue';
cfg.forward.exchange_dir = fullfile(pwd,'private_exchange');
cfg.forward.timeout_seconds = 7200;
cfg.forward.poll_seconds = 1.0;
cfg.forward.cancel_grace_seconds = 120;
cfg.forward.worker_heartbeat_timeout_seconds = 30;
cfg.forward.max_clock_skew_seconds = 5;
cfg.forward.required_worker_version = '0.3.0';
% SHA-256 of the private restored model + boundary groups + point mapping.
cfg.forward.model_config_hash = repmat('0',1,64); % PROJECT-SPECIFIC
cfg.forward.keep_job_files = true;

cfg.output_dir = fullfile(pwd,'private_results');
cfg.checkpoint_file = fullfile(cfg.output_dir,'socbo_checkpoint.mat');
cfg.resume = false;
end
