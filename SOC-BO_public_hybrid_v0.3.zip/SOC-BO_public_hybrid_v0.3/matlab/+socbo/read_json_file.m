function value = read_json_file(filename)
%READ_JSON_FILE Read and decode one UTF-8 JSON object.
assert(isfile(filename),'SOCBO:JSONMissing','JSON file does not exist: %s',filename);
value = jsondecode(fileread(filename));
assert(isstruct(value) && isscalar(value),'SOCBO:JSONRoot', ...
    'JSON root must be one object: %s',filename);
end
