function score = constrained_acquisition(Xcand, gp_obj, gp_cons, tol, beta, y_best, cfg)
%CONSTRAINED_ACQUISITION EI multiplied by tempered joint PoF.

[mu_obj,sd_obj] = predict(gp_obj,Xcand);
ei = socbo.expected_improvement(mu_obj,sd_obj,y_best,cfg.acquisition.xi, ...
    cfg.acquisition.min_predictive_sd);
log_pof = zeros(size(ei));
for j = 1:numel(gp_cons)
    [mu,sd] = predict(gp_cons{j},Xcand);
    p = zeros(size(mu));
    regular = sd > cfg.acquisition.min_predictive_sd;
    p(regular) = normcdf((tol(j)-mu(regular))./sd(regular));
    p(~regular) = double(mu(~regular) <= tol(j));
    p = min(max(p,cfg.acquisition.probability_floor),1);
    log_pof = log_pof + log(p);
end
score = ei .* exp(beta*log_pof);
score(~isfinite(score)) = 0;
end
