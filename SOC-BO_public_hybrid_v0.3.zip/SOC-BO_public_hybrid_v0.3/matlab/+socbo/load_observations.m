function obs = load_observations(cfg)
%LOAD_OBSERVATIONS Load HF data and construct native FLAC3D observables.
%
% Required CSV columns:
% point_id,borehole_id,sh_max_mpa,sh_min_mpa,sv_mpa,sh_azimuth_deg,
% stress_weight,orientation_weight

T = readtable(cfg.observation.hf_file,'TextType','string', ...
    'VariableNamingRule','preserve');
required = {'point_id','borehole_id','sh_max_mpa','sh_min_mpa','sv_mpa', ...
    'sh_azimuth_deg','stress_weight','orientation_weight'};
assert(all(ismember(required,T.Properties.VariableNames)), ...
    'SOCBO:HFColumns','HF file is missing one or more required columns.');
assert(height(T)>0,'SOCBO:HFEmpty','HF observation file is empty.');

SH = T.sh_max_mpa; Sh = T.sh_min_mpa; Sv = T.sv_mpa;
az = T.sh_azimuth_deg; ws = T.stress_weight; wo = T.orientation_weight;
assert(isnumeric(SH) && isnumeric(Sh) && isnumeric(Sv) && isnumeric(az) && ...
    isnumeric(ws) && isnumeric(wo),'SOCBO:HFNumeric', ...
    'HF stress, azimuth, and weight columns must be numeric.');
assert(all(isfinite([SH;Sh;Sv;az;ws;wo])),'SOCBO:HFFinite', ...
    'HF observations contain NaN or Inf.');
assert(all(SH>=Sh) && all(Sh>=0) && all(Sv>=0),'SOCBO:HFStressMagnitude', ...
    'HF stresses must be non-negative magnitudes with SH >= Sh.');
assert(all(ws>=0) && sum(ws)>0,'SOCBO:StressWeights', ...
    'stress_weight must be non-negative and positive in total.');
assert(all(wo>=0) && sum(wo)>0,'SOCBO:OrientationWeights', ...
    'orientation_weight must be non-negative and positive in total.');

point_id = string(T.point_id);
assert(all(strlength(point_id)>0) && numel(unique(point_id))==height(T), ...
    'SOCBO:ObservationPointIDs','point_id values must be unique and non-empty.');
file_bh = string(T.borehole_id);
config_bh = string(cfg.constraints.borehole_ids(:));
[is_known,bh_idx] = ismember(file_bh,config_bh);
assert(all(is_known),'SOCBO:UnknownBorehole', ...
    'Every borehole_id must appear in cfg.constraints.borehole_ids.');
assert(all(ismember(config_bh,unique(file_bh,'stable'))), ...
    'SOCBO:MissingBorehole','Every configured borehole must have observations.');

obs.point_id = point_id;
obs.borehole_name = config_bh;
obs.borehole_index = bh_idx;
obs.n_boreholes = numel(config_bh);
obs.SH_mpa = SH(:); obs.Sh_mpa = Sh(:); obs.Sv_mpa = Sv(:);
obs.azimuth_deg = mod(az(:),180);
obs.stress_weight = ws(:);
if cfg.constraints.use_orientation_weights
    obs.orientation_weight = wo(:);
else
    obs.orientation_weight = ones(height(T),1);
end
obs.observable_pa = socbo.hf_to_model_observables(obs.SH_mpa,obs.Sh_mpa, ...
    obs.Sv_mpa,obs.azimuth_deg,cfg.coordinates.model_x_azimuth_deg);
assert(obs.n_boreholes==numel(cfg.constraints.final_tolerance_deg), ...
    'SOCBO:BoreholeToleranceCount', ...
    'Configured borehole count must equal the number of final tolerances.');
end
