function status = find_live_worker(paths,cfg)
%FIND_LIVE_WORKER Return the freshest compatible FLAC3D worker heartbeat.
files = dir(fullfile(paths.workers,'worker_*.json'));
now_s = socbo.unix_time();
best_age = inf; status = struct([]); rejected = strings(0,1);
for i = 1:numel(files)
    filename = fullfile(files(i).folder,files(i).name);
    try
        candidate = socbo.read_json_file(filename);
        assert(isfield(candidate,'protocol') && strcmp(candidate.protocol,'SOCBO_FILE_QUEUE'));
        assert(isfield(candidate,'schema_version') && strcmp(candidate.schema_version,'1.0'));
        assert(isfield(candidate,'heartbeat_epoch_s') && isfinite(candidate.heartbeat_epoch_s));
        assert(isfield(candidate,'status') && ...
            ismember(string(candidate.status),["idle","busy","finalizing"]));
        age = now_s-double(candidate.heartbeat_epoch_s);
        assert(age>=-cfg.forward.max_clock_skew_seconds);
        assert(age<=cfg.forward.worker_heartbeat_timeout_seconds);
        assert(isfield(candidate,'worker_version') && ...
            strcmp(candidate.worker_version,cfg.forward.required_worker_version));
        assert(isfield(candidate,'model_config_hash') && ...
            strcmpi(candidate.model_config_hash,cfg.forward.model_config_hash));
        assert(isfield(candidate,'adapter_info') && isfield(candidate.adapter_info,'flac3d') && ...
            startsWith(string(candidate.adapter_info.flac3d),string(cfg.software.flac3d)));
        if age<best_age
            status = candidate; best_age = age;
        end
    catch ME
        rejected(end+1,1) = string(files(i).name)+": "+string(ME.message); %#ok<AGROW>
    end
end
if isempty(status)
    detail = strjoin(rejected,newline);
    error('SOCBO:NoCompatibleWorker', ...
        ['No live compatible FLAC3D worker was found in %s. ', ...
         'Start the v%s worker with the same model_config_hash.\n%s'], ...
        paths.workers,cfg.forward.required_worker_version,detail);
end
end
