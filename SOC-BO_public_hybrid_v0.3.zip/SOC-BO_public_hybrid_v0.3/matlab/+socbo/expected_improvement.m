function ei = expected_improvement(mu, sd, y_best, xi, min_sd)
%EXPECTED_IMPROVEMENT Stable EI for minimization.

mu = mu(:); sd = sd(:);
assert(numel(mu)==numel(sd), 'SOCBO:EISize', 'mu and sd must have equal length.');
assert(isscalar(y_best) && isfinite(y_best), 'SOCBO:EIIncumbent', 'y_best must be finite.');
improvement = y_best - mu - xi;
ei = zeros(size(mu));
regular = sd > min_sd;
z = improvement(regular)./sd(regular);
ei(regular) = improvement(regular).*normcdf(z) + sd(regular).*normpdf(z);
ei(~regular) = max(improvement(~regular),0);
ei = max(ei,0);
ei(~isfinite(ei)) = 0;
end
