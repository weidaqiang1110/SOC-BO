function [SH_pa,Sh_pa,azimuth_deg] = sh_from_stress(stress6_pa,model_x_azimuth_deg)
%SH_FROM_STRESS Positive horizontal compression magnitudes and SH azimuth.
%
% Input is native FLAC3D total stress in Pa, ordered
% [sxx syy szz sxy syz sxz], with tension positive and compression negative.
% Because SH is the maximum compressive horizontal stress, it corresponds to
% the smallest eigenvalue. SH_pa and Sh_pa are returned as positive field-
% reporting magnitudes; the tensor signs are not altered elsewhere.

validateattributes(stress6_pa,{'numeric'},{'2d','finite','real'});
assert(size(stress6_pa,2)==6,'SOCBO:StressComponents', ...
    'stress6_pa must have six columns.');
assert(isscalar(model_x_azimuth_deg) && isfinite(model_x_azimuth_deg), ...
    'SOCBO:ModelAzimuth','model_x_azimuth_deg must be finite.');

n = size(stress6_pa,1);
SH_pa = zeros(n,1); Sh_pa = zeros(n,1); azimuth_deg = zeros(n,1);
a = deg2rad(model_x_azimuth_deg);
Q = [sin(a),-cos(a);cos(a),sin(a)];
for i = 1:n
    H = [stress6_pa(i,1),stress6_pa(i,4); ...
         stress6_pa(i,4),stress6_pa(i,2)];
    H = 0.5*(H+H.');
    [V,D] = eig(H,'vector');
    [vals,order] = sort(D,'ascend');
    v_geo = Q*V(:,order(1));
    SH_pa(i) = -vals(1);
    Sh_pa(i) = -vals(2);
    azimuth_deg(i) = mod(rad2deg(atan2(v_geo(1),v_geo(2))),180);
end
end
