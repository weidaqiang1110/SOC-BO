function [stress_pa,metadata] = run_flac3d_file_exchange(x,point_ids,cfg,candidate_index)
%RUN_FLAC3D_FILE_EXCHANGE Submit one v0.3 persistent file-queue task.
%
% Output stress_pa retains FLAC3D's native convention and units:
% tension positive, compression negative, Pa, columns
% [sxx syy szz sxy syz sxz]. No sign reversal is performed.

if nargin<4, candidate_index = NaN; end
x = x(:).'; point_ids = string(point_ids(:));
assert(numel(x)==6 && all(isfinite(x)),'SOCBO:ForwardParameters', ...
    'The forward request requires six finite parameter values.');
assert(numel(unique(point_ids))==numel(point_ids) && all(strlength(point_ids)>0), ...
    'SOCBO:PointIDs','Observation point IDs must be unique and non-empty.');

paths = socbo.ensure_exchange_layout(cfg.forward.exchange_dir);
worker = socbo.find_live_worker(paths,cfg); %#ok<NASGU>
run_id = char(java.util.UUID.randomUUID);
tmp_dir = fullfile(paths.queued,['.',run_id,'.tmp']);
queued_dir = fullfile(paths.queued,run_id);
assert(~isfolder(tmp_dir) && ~isfolder(queued_dir),'SOCBO:TaskCollision', ...
    'Unexpected task-directory collision for %s.',run_id);
mkdir(tmp_dir);
cleanup_tmp = onCleanup(@() remove_tmp());

request.protocol = 'SOCBO_FILE_QUEUE';
request.schema_version = '1.0';
request.run_id = run_id;
request.candidate_index = candidate_index;
request.created_epoch_s = socbo.unix_time();
request.software.matlab = cfg.software.matlab;
request.software.flac3d = cfg.software.flac3d;
request.parameters.names = cfg.parameter_names;
request.parameters.units = cfg.parameter_units;
request.parameters.values = x;
request.stress_sign_convention = 'tension_positive_compression_negative';
request.stress_output_unit = 'Pa';
request.stress_component_order = {'sxx','syy','szz','sxy','syz','sxz'};
request.azimuth_convention = 'clockwise_from_geographic_north_axial_180_deg';
request.expected_point_ids = cellstr(point_ids);
request.expected_n_points = numel(point_ids);
request.model_config_hash = lower(cfg.forward.model_config_hash);
request.model_x_azimuth_deg = cfg.coordinates.model_x_azimuth_deg;
request.linear_profile.z_top_m = cfg.loading.linear_profile.z_top;
request.linear_profile.z_bottom_m = cfg.loading.linear_profile.z_bottom;
request.linear_profile.clip = cfg.loading.linear_profile.clip;

socbo.atomic_write_json(fullfile(tmp_dir,'request.json'),request);
parameter_table = table(string(cfg.parameter_names(:)),x(:), ...
    string(cfg.parameter_units(:)),'VariableNames',{'parameter_name','value','unit'});
writetable(parameter_table,fullfile(tmp_dir,'parameters.csv'));
socbo.atomic_write_text(fullfile(tmp_dir,'READY'),[run_id,newline]);
[ok,msg] = movefile(tmp_dir,queued_dir);
assert(ok,'SOCBO:TaskPublish','Failed to publish queued task: %s',msg);
clear cleanup_tmp

started = tic;
timed_out = false;
while true
    completed_dir = fullfile(paths.completed,run_id);
    failed_dir = fullfile(paths.failed,run_id);
    cancelled_dir = fullfile(paths.cancelled,run_id);
    if isfolder(completed_dir)
        [stress_pa,metadata] = read_completed(completed_dir);
        if ~cfg.forward.keep_job_files, rmdir(completed_dir,'s'); end
        return
    end
    if isfolder(failed_dir)
        raise_terminal_error(failed_dir,'SOCBO:ForwardFailed');
    end
    if isfolder(cancelled_dir)
        raise_terminal_error(cancelled_dir,'SOCBO:ForwardCancelled');
    end
    if toc(started)>cfg.forward.timeout_seconds && ~timed_out
        timed_out = true;
        wrote = socbo.write_cancel_marker(paths,run_id, ...
            sprintf('MATLAB timeout after %.3f seconds.',cfg.forward.timeout_seconds));
        cancel_started = tic;
        if ~wrote
            warning('SOCBO:CancelRace', ...
                'Timeout occurred, but the task moved while cancellation was requested.');
        end
    end
    if timed_out && toc(cancel_started)>cfg.forward.cancel_grace_seconds
        error('SOCBO:ForwardTimeout', ...
            ['FLAC3D task %s exceeded %.1f s and did not acknowledge ', ...
             'cancellation within %.1f s. Task files were retained for recovery.'], ...
            run_id,cfg.forward.timeout_seconds,cfg.forward.cancel_grace_seconds);
    end
    pause(cfg.forward.poll_seconds);
end

    function [stress,meta] = read_completed(task_dir)
        result_file = fullfile(task_dir,'result.json');
        result = socbo.read_json_file(result_file);
        assert(strcmp(result.run_id,run_id) && strcmp(result.status,'succeeded'), ...
            'SOCBO:ResultIdentity','Completed result identity/status is invalid.');
        assert(strcmp(result.protocol,'SOCBO_FILE_QUEUE') && ...
            strcmp(result.schema_version,'1.0'),'SOCBO:ResultSchema', ...
            'Result protocol/schema is incompatible.');
        assert(strcmp(result.worker_version,cfg.forward.required_worker_version), ...
            'SOCBO:WorkerVersion','Result was produced by an incompatible worker version.');
        assert(strcmpi(result.model_config_hash,cfg.forward.model_config_hash), ...
            'SOCBO:ModelHash','Result model_config_hash does not match MATLAB config.');
        assert(strcmp(result.stress_sign_convention, ...
            'tension_positive_compression_negative'),'SOCBO:StressConvention', ...
            'Result stress sign convention is not native FLAC3D.');
        assert(strcmp(result.stress_unit,'Pa'),'SOCBO:StressUnit', ...
            'Result stress unit must be Pa.');
        expected_order = ["sxx","syy","szz","sxy","syz","sxz"];
        assert(isequal(string(result.stress_component_order(:)).',expected_order), ...
            'SOCBO:StressOrder','Result stress component order is incompatible.');
        assert(logical(result.converged),'SOCBO:Unconverged', ...
            'FLAC3D result is marked unconverged.');
        stress_file = fullfile(task_dir,char(result.stress_file));
        actual_hash = socbo.sha256_file(stress_file);
        assert(strcmpi(actual_hash,result.stress_sha256),'SOCBO:StressChecksum', ...
            'stress.csv SHA-256 checksum mismatch.');
        T = readtable(stress_file,'TextType','string','VariableNamingRule','preserve');
        expected_columns = {'point_id','sxx_pa','syy_pa','szz_pa','sxy_pa','syz_pa','sxz_pa'};
        assert(isequal(T.Properties.VariableNames,expected_columns), ...
            'SOCBO:StressColumns','stress.csv columns do not match the protocol.');
        returned_ids = string(T.point_id);
        assert(numel(unique(returned_ids))==height(T),'SOCBO:DuplicatePointIDs', ...
            'stress.csv contains duplicate point IDs.');
        [found,location] = ismember(point_ids,returned_ids);
        assert(all(found) && height(T)==numel(point_ids),'SOCBO:PointIDMismatch', ...
            'FLAC3D output point IDs do not exactly match observations.');
        numeric = T{:,2:7};
        assert(isnumeric(numeric) && all(isfinite(numeric),'all'), ...
            'SOCBO:StressFinite','stress.csv contains non-finite values.');
        stress = numeric(location,:);
        assert(isequal(size(stress),[numel(point_ids),6]),'SOCBO:ForwardShape', ...
            'FLAC3D returned an unexpected stress matrix shape.');
        meta = result;
    end

    function raise_terminal_error(task_dir,error_id)
        message = 'No worker diagnostic was provided.';
        error_file = fullfile(task_dir,'error.txt');
        cancel_file = fullfile(task_dir,'cancelled.txt');
        if isfile(error_file), message = fileread(error_file); end
        if isfile(cancel_file), message = fileread(cancel_file); end
        error(error_id,'FLAC3D task %s terminated:\n%s',run_id,message);
    end

    function remove_tmp()
        if isfolder(tmp_dir), rmdir(tmp_dir,'s'); end
    end
end
