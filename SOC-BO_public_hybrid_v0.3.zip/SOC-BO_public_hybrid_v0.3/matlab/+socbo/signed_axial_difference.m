function delta_deg = signed_axial_difference(sim_deg, obs_deg)
%SIGNED_AXIAL_DIFFERENCE Signed difference for 180-degree-periodic axes.
% Positive values indicate clockwise rotation of simulation relative to
% observation under a clockwise-from-North geographic convention.

assert(isequal(size(sim_deg),size(obs_deg)) || isscalar(sim_deg) || isscalar(obs_deg), ...
    'SOCBO:AngleSize', 'Angle arrays must be compatible.');
assert(all(isfinite(sim_deg),'all') && all(isfinite(obs_deg),'all'), ...
    'SOCBO:AngleFinite', 'Angles must be finite.');
delta_deg = mod(sim_deg - obs_deg + 90, 180) - 90;
end
