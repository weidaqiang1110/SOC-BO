function [y_best,index,has_feasible] = select_incumbent(y_obj,y_cons,tol)
%SELECT_INCUMBENT Best evaluated feasible objective; fallback to best observed.

feasible = all(y_cons <= tol(:).',2);
has_feasible = any(feasible);
if has_feasible
    idxs = find(feasible);
    [y_best,k] = min(y_obj(feasible));
    index = idxs(k);
else
    [y_best,index] = min(y_obj);
end
end
