function tol = current_tolerance(cfg,iteration)
%CURRENT_TOLERANCE Evaluate the configured borehole-tolerance schedule.

p = (iteration-1)/max(cfg.n_iter-1,1);
initial = cfg.constraints.initial_tolerance_deg;
final = cfg.constraints.final_tolerance_deg;
switch lower(cfg.constraints.relaxation.type)
    case 'fixed'
        tol = final;
    case 'exponential'
        rho = cfg.constraints.relaxation.rho;
        tol = final+(initial-final).*exp(-rho*p);
    otherwise
        error('SOCBO:ToleranceSchedule','Unsupported relaxation type: %s', ...
            cfg.constraints.relaxation.type);
end
end
