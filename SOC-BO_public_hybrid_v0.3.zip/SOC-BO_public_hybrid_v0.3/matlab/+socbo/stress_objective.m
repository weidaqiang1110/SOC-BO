function [objective,point_misfit,sim_observable_pa] = stress_objective(sim_stress6_pa,obs_observable_pa,weights,eta_pa)
%STRESS_OBJECTIVE Weighted point-normalized HF-observable mismatch.
%
% Both simulated and observed tensors use native FLAC3D signs and Pa. The
% compared vector is [sxx,syy,sxy,sv=szz]. No stress sign conversion occurs.

validateattributes(sim_stress6_pa,{'numeric'},{'2d','finite','real'});
validateattributes(obs_observable_pa,{'numeric'},{'2d','finite','real'});
assert(size(sim_stress6_pa,2)==6,'SOCBO:StressComponents', ...
    'sim_stress6_pa must have six columns.');
assert(size(obs_observable_pa,2)==4,'SOCBO:HFObservableColumns', ...
    'obs_observable_pa must contain [sxx,syy,sxy,sv].');
assert(size(sim_stress6_pa,1)==size(obs_observable_pa,1),'SOCBO:StressRows', ...
    'Simulated and observed row counts must agree.');
weights = weights(:);
assert(numel(weights)==size(sim_stress6_pa,1),'SOCBO:WeightSize', ...
    'One stress weight is required per observation point.');
assert(all(isfinite(weights)) && all(weights>=0) && sum(weights)>0, ...
    'SOCBO:WeightsInvalid','Weights must be finite and non-negative.');
assert(isscalar(eta_pa) && isfinite(eta_pa) && eta_pa>0,'SOCBO:EtaInvalid', ...
    'eta_pa must be one positive finite scalar in Pa.');

sim_observable_pa = sim_stress6_pa(:,[1,2,4,3]);
num = vecnorm(sim_observable_pa-obs_observable_pa,2,2);
den = vecnorm(obs_observable_pa,2,2)+eta_pa;
point_misfit = num./den;
objective = sum(weights.*point_misfit)/sum(weights);
assert(isscalar(objective) && isfinite(objective),'SOCBO:ObjectiveInvalid', ...
    'Objective must be one finite scalar.');
end
