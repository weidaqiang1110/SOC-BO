function wrote = write_cancel_marker(paths,run_id,message)
%WRITE_CANCEL_MARKER Request cancellation in queued or running task state.
wrote = false;
for parent = {paths.queued,paths.running}
    task_dir = fullfile(parent{1},run_id);
    if isfolder(task_dir)
        try
            socbo.atomic_write_text_existing(fullfile(task_dir,'CANCEL'),[char(message),newline]);
            wrote = true;
        catch
            % The worker may move the directory between the existence check and write.
        end
    end
end
end
