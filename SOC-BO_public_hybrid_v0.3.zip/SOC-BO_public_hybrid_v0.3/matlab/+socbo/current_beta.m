function beta = current_beta(cfg, iteration)
%CURRENT_BETA Logistic PoF-exponent schedule.
progress = (iteration-1) / max(cfg.n_iter-1,1);
s = 1/(1+exp(-cfg.acquisition.anneal_slope*(progress-0.5)));
beta = cfg.acquisition.beta_start + ...
    (cfg.acquisition.beta_end-cfg.acquisition.beta_start)*s;
end
