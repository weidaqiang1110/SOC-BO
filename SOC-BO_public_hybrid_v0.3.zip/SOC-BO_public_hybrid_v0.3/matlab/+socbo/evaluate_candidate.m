function result = evaluate_candidate(x,obs,cfg,candidate_index)
%EVALUATE_CANDIDATE Run FLAC3D and calculate SOC-BO metrics.
if nargin<4, candidate_index = NaN; end
switch lower(cfg.forward.mode)
    case 'flac3d_persistent_file_queue'
        [sim_stress_pa,forward_metadata] = socbo.run_flac3d_file_exchange( ...
            x,obs.point_id,cfg,candidate_index);
    otherwise
        error('SOCBO:ForwardMode','Unsupported forward mode: %s',cfg.forward.mode);
end

[SH_pa,Sh_pa,sim_azimuth] = socbo.sh_from_stress(sim_stress_pa, ...
    cfg.coordinates.model_x_azimuth_deg);
[objective,point_misfit,sim_observable_pa] = socbo.stress_objective( ...
    sim_stress_pa,obs.observable_pa,obs.stress_weight,cfg.observation.eta_pa);
orient = socbo.borehole_orientation_metrics(sim_azimuth,obs.azimuth_deg, ...
    obs.borehole_index,obs.orientation_weight,obs.n_boreholes);

result.sim_stress_pa = sim_stress_pa;
result.sim_observable_pa = sim_observable_pa;
result.sim_SH_pa = SH_pa;
result.sim_Sh_pa = Sh_pa;
result.sim_SH_mpa = SH_pa/1.0e6;
result.sim_Sh_mpa = Sh_pa/1.0e6;
result.sim_azimuth_deg = sim_azimuth;
result.objective = objective;
result.point_misfit = point_misfit;
result.orientation = orient;
result.forward_metadata = forward_metadata;
end
