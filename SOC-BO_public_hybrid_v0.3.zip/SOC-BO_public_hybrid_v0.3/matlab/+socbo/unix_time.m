function value = unix_time()
%UNIX_TIME Current UTC POSIX time in seconds.
value = posixtime(datetime('now','TimeZone','UTC'));
end
