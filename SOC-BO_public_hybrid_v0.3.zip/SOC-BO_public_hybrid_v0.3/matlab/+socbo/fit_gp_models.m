function [gp_obj, gp_cons] = fit_gp_models(X, y_obj, y_cons, cfg)
%FIT_GP_MODELS Fit objective and independent constraint GPs.

assert(size(X,1)==numel(y_obj) && size(X,1)==size(y_cons,1), ...
    'SOCBO:GPTrainingSize', 'Training row counts must agree.');
common = {'KernelFunction',cfg.gp.kernel, ...
    'BasisFunction',cfg.gp.basis, ...
    'Standardize',cfg.gp.standardize, ...
    'FitMethod','exact','PredictMethod','exact', ...
    'SigmaLowerBound',cfg.gp.sigma_lower_bound};

gp_obj = fitrgp(X,y_obj(:),common{:});
gp_cons = cell(size(y_cons,2),1);
for j = 1:size(y_cons,2)
    gp_cons{j} = fitrgp(X,y_cons(:,j),common{:});
end
end
