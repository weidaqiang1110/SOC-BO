function atomic_write_text_existing(filename,text)
%ATOMIC_WRITE_TEXT_EXISTING Atomically write only if parent still exists.
folder = fileparts(filename);
assert(isfolder(folder),'SOCBO:ParentMissing','Parent directory disappeared: %s',folder);
tmp = [filename,'.tmp'];
fid = fopen(tmp,'w','n','UTF-8');
assert(fid>0,'SOCBO:AtomicWrite','Cannot open temporary file %s.',tmp);
cleanup = onCleanup(@() close_if_open());
fprintf(fid,'%s',char(text));
fclose(fid); fid = -1;
[ok,msg] = movefile(tmp,filename,'f');
assert(ok,'SOCBO:AtomicWrite','Failed to finalize %s: %s',filename,msg);

    function close_if_open()
        if fid>0, fclose(fid); end
        if isfile(tmp), delete(tmp); end
    end
end
