function metrics = borehole_orientation_metrics(sim_azimuth_deg,obs_azimuth_deg,borehole_index,weights,n_boreholes)
%BOREHOLE_ORIENTATION_METRICS Weighted RMSE and signed mean by borehole.

sim_azimuth_deg = sim_azimuth_deg(:);
obs_azimuth_deg = obs_azimuth_deg(:);
borehole_index = borehole_index(:);
weights = weights(:);
n = numel(sim_azimuth_deg);
assert(numel(obs_azimuth_deg)==n && numel(borehole_index)==n && numel(weights)==n, ...
    'SOCBO:OrientationSize','All orientation inputs must have equal length.');
assert(isscalar(n_boreholes) && n_boreholes>=1 && fix(n_boreholes)==n_boreholes, ...
    'SOCBO:BoreholeCount','n_boreholes must be a positive integer.');
assert(all(weights>=0) && all(isfinite(weights)) && ...
    all(borehole_index>=1 & borehole_index<=n_boreholes & fix(borehole_index)==borehole_index), ...
    'SOCBO:OrientationInputs','Orientation weights or borehole indices are invalid.');

delta = socbo.signed_axial_difference(sim_azimuth_deg,obs_azimuth_deg);
rmse = zeros(1,n_boreholes); signed_mean = zeros(1,n_boreholes); counts = zeros(1,n_boreholes);
for j = 1:n_boreholes
    idx = borehole_index==j;
    assert(any(idx),'SOCBO:EmptyBorehole','Borehole %d has no observations.',j);
    w = weights(idx);
    assert(sum(w)>0,'SOCBO:BoreholeWeights', ...
        'Borehole %d must have positive total orientation weight.',j);
    d = delta(idx);
    rmse(j) = sqrt(sum(w.*d.^2)/sum(w));
    signed_mean(j) = sum(w.*d)/sum(w);
    counts(j) = nnz(idx);
end
metrics.delta_deg = delta;
metrics.rmse_deg = rmse;
metrics.signed_mean_deg = signed_mean;
metrics.count = counts;
metrics.overall_rmse_deg = sqrt(sum(weights.*delta.^2)/sum(weights));
metrics.overall_signed_mean_deg = sum(weights.*delta)/sum(weights);
end
