function observable_pa = hf_to_model_observables(SH_mpa,Sh_mpa,Sv_mpa,azimuth_deg,model_x_azimuth_deg)
%HF_TO_MODEL_OBSERVABLES Convert HF magnitudes to native FLAC3D components.
%
% SH_mpa, Sh_mpa, and Sv_mpa are conventional positive compression
% magnitudes. Output is [sxx,syy,sxy,sv] in Pa with FLAC3D's native stress
% convention: tension positive and compression negative.

SH_mpa = SH_mpa(:); Sh_mpa = Sh_mpa(:); Sv_mpa = Sv_mpa(:);
azimuth_deg = azimuth_deg(:); n = numel(SH_mpa);
assert(numel(Sh_mpa)==n && numel(Sv_mpa)==n && numel(azimuth_deg)==n, ...
    'SOCBO:HFSize','SH, Sh, Sv, and azimuth must have equal length.');
assert(all(isfinite([SH_mpa;Sh_mpa;Sv_mpa;azimuth_deg])) && ...
    isfinite(model_x_azimuth_deg),'SOCBO:HFFinite', ...
    'HF values and coordinate azimuth must be finite.');
assert(all(SH_mpa>=Sh_mpa) && all(Sh_mpa>=0) && all(Sv_mpa>=0), ...
    'SOCBO:HFPrincipalOrder', ...
    'Require non-negative magnitudes with SH >= Sh at every point.');

alpha = deg2rad(model_x_azimuth_deg);
% Model basis columns expressed in geographic [East; North].
Q = [sin(alpha),-cos(alpha);cos(alpha),sin(alpha)];
observable_pa = zeros(n,4);
for i = 1:n
    beta = deg2rad(azimuth_deg(i));
    v_geo = [sin(beta);cos(beta)];
    % Native FLAC3D tensor: -SH along v_geo and -Sh perpendicular.
    H_geo_mpa = -Sh_mpa(i)*eye(2) - ...
        (SH_mpa(i)-Sh_mpa(i))*(v_geo*v_geo.');
    H_model_pa = 1.0e6*(Q.'*H_geo_mpa*Q);
    H_model_pa = 0.5*(H_model_pa+H_model_pa.');
    observable_pa(i,:) = [H_model_pa(1,1),H_model_pa(2,2), ...
        H_model_pa(1,2),-Sv_mpa(i)*1.0e6];
end
end
