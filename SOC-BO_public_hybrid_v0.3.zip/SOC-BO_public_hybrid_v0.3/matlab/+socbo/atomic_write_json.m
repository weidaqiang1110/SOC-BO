function atomic_write_json(filename,value)
%ATOMIC_WRITE_JSON Atomically write one JSON object.
text = jsonencode(value);
socbo.atomic_write_text(filename,[text,newline]);
end
