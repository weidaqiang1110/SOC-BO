function hex = sha256_file(filename)
%SHA256_FILE Return the lowercase SHA-256 digest of a file.
assert(isfile(filename),'SOCBO:HashMissing','Cannot hash missing file: %s',filename);
import java.security.MessageDigest
import java.io.FileInputStream
import java.io.DigestInputStream
md = MessageDigest.getInstance('SHA-256');
stream = FileInputStream(java.io.File(filename));
digestStream = DigestInputStream(stream,md);
cleanup = onCleanup(@() digestStream.close());
while digestStream.read() ~= -1
    % Read to EOF; stress/result files are small.
end
raw = int8(md.digest());
bytes = typecast(raw,'uint8');
hex = lower(reshape(dec2hex(bytes,2).',1,[]));
end
