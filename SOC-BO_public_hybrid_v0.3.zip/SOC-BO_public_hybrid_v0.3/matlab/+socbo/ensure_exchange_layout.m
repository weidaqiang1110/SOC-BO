function paths = ensure_exchange_layout(exchange_dir)
%ENSURE_EXCHANGE_LAYOUT Create and return v0.3 persistent-queue directories.
paths.root = char(exchange_dir);
names = {'queued','running','completed','failed','cancelled','workers'};
for i = 1:numel(names)
    paths.(names{i}) = fullfile(paths.root,names{i});
    if ~isfolder(paths.(names{i})), mkdir(paths.(names{i})); end
end
end
