"""HF-observation and horizontal-stress utilities in FLAC3D convention.

Conventions
-----------
* tensor stress sign: FLAC3D native, tension positive and compression negative;
* tensor stress unit: Pa unless explicitly stated otherwise;
* component order: ``[sxx, syy, szz, sxy, syz, sxz]``;
* field ``SH``, ``Sh``, and ``Sv`` inputs/outputs: positive compression
  magnitudes, because that is the conventional reporting form for hydraulic-
  fracturing measurements;
* geographic azimuth: clockwise from North, axial with 180° periodicity;
* model coordinates: right-handed, +Z upward, +Y at azimuth ``alpha-90°`` when
  model +X has geographic azimuth ``alpha``.
"""
from __future__ import annotations

from typing import Tuple

import numpy as np


def _as_stress6(stress6_pa: np.ndarray) -> np.ndarray:
    arr = np.asarray(stress6_pa, dtype=float)
    if arr.ndim == 1:
        if arr.size % 6 != 0:
            raise ValueError("A flat stress array must contain 6*n values.")
        arr = arr.reshape((-1, 6))
    if arr.ndim != 2 or arr.shape[1] != 6:
        raise ValueError("stress6_pa must have shape (n, 6).")
    if not np.isfinite(arr).all():
        raise ValueError("stress6_pa contains NaN or Inf.")
    return arr


def model_basis_geographic(model_x_azimuth_deg: float) -> np.ndarray:
    """Return model [x,y] basis columns in geographic [East,North]."""
    alpha = np.deg2rad(float(model_x_azimuth_deg))
    if not np.isfinite(alpha):
        raise ValueError("model_x_azimuth_deg must be finite.")
    return np.array(
        [[np.sin(alpha), -np.cos(alpha)], [np.cos(alpha), np.sin(alpha)]],
        dtype=float,
    )


def hf_to_model_observables_pa(
    sh_max_mpa: np.ndarray,
    sh_min_mpa: np.ndarray,
    sv_mpa: np.ndarray,
    sh_azimuth_deg: np.ndarray,
    model_x_azimuth_deg: float,
) -> np.ndarray:
    """Convert positive HF magnitudes to FLAC-native model components in Pa.

    Returns columns ``[sxx, syy, sxy, sv]``. Compression is negative.
    """
    sh_max = np.asarray(sh_max_mpa, dtype=float).reshape(-1)
    sh_min = np.asarray(sh_min_mpa, dtype=float).reshape(-1)
    sv = np.asarray(sv_mpa, dtype=float).reshape(-1)
    az = np.asarray(sh_azimuth_deg, dtype=float).reshape(-1)
    n = sh_max.size
    if sh_min.size != n or sv.size != n or az.size != n:
        raise ValueError("SH, Sh, Sv, and azimuth arrays must have equal length.")
    if not np.isfinite(np.concatenate([sh_max, sh_min, sv, az])).all():
        raise ValueError("HF observations contain NaN or Inf.")
    if np.any(sh_max < sh_min):
        raise ValueError("Every SH magnitude must be greater than or equal to Sh.")
    if np.any(sh_min < 0.0) or np.any(sv < 0.0):
        raise ValueError("HF stress magnitudes must be non-negative.")

    q = model_basis_geographic(model_x_azimuth_deg)
    out = np.empty((n, 4), dtype=float)
    for i in range(n):
        beta = np.deg2rad(az[i])
        v_geo = np.array([np.sin(beta), np.cos(beta)], dtype=float)
        # Native FLAC3D tensor: eigenvalue -SH along v and -Sh perpendicular.
        h_geo_mpa = -sh_min[i] * np.eye(2) - (
            sh_max[i] - sh_min[i]
        ) * np.outer(v_geo, v_geo)
        h_model_pa = 1.0e6 * (q.T @ h_geo_mpa @ q)
        h_model_pa = 0.5 * (h_model_pa + h_model_pa.T)
        out[i] = [
            h_model_pa[0, 0],
            h_model_pa[1, 1],
            h_model_pa[0, 1],
            -sv[i] * 1.0e6,
        ]
    return out


def sh_from_flac_stress_pa(
    stress6_pa: np.ndarray, model_x_azimuth_deg: float
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return positive ``SH``/``Sh`` magnitudes [Pa] and geographic SH azimuth.

    Because compression is negative in FLAC3D, ``SH`` is associated with the
    smallest horizontal eigenvalue. Magnitudes are returned as the negatives of
    the corresponding signed eigenvalues for conventional field reporting.
    """
    arr = _as_stress6(stress6_pa)
    q = model_basis_geographic(model_x_azimuth_deg)
    sh_max = np.empty(arr.shape[0], dtype=float)
    sh_min = np.empty(arr.shape[0], dtype=float)
    azimuth = np.empty(arr.shape[0], dtype=float)
    for i, row in enumerate(arr):
        h = np.array([[row[0], row[3]], [row[3], row[1]]], dtype=float)
        h = 0.5 * (h + h.T)
        values, vectors = np.linalg.eigh(h)  # ascending: most compressive first
        v_geo = q @ vectors[:, 0]
        sh_max[i] = -values[0]
        sh_min[i] = -values[1]
        azimuth[i] = np.degrees(np.arctan2(v_geo[0], v_geo[1])) % 180.0
    return sh_max, sh_min, azimuth


def signed_axial_difference(sim_deg: np.ndarray, obs_deg: np.ndarray) -> np.ndarray:
    """Return signed 180-degree-periodic difference in ``[-90, 90)``."""
    sim = np.asarray(sim_deg, dtype=float)
    obs = np.asarray(obs_deg, dtype=float)
    if not np.isfinite(sim).all() or not np.isfinite(obs).all():
        raise ValueError("Angles must be finite.")
    return (sim - obs + 90.0) % 180.0 - 90.0
