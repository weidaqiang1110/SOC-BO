"""Persistent file-queue protocol used between MATLAB and FLAC3D.

The protocol intentionally keeps the numerical payload human-readable while
adding explicit schema, sign, unit, point-ID, checksum, and status metadata.
All solver stress tensors retain FLAC3D's native convention:
positive in tension and negative in compression.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np

from .constants import (
    AZIMUTH_CONVENTION,
    PARAMETER_NAMES,
    PARAMETER_UNITS,
    PROTOCOL_NAME,
    SCHEMA_VERSION,
    STRESS_COMPONENTS,
    STRESS_CSV_COLUMNS,
    STRESS_SIGN_CONVENTION,
    STRESS_UNIT,
)


@dataclass
class ForwardResult:
    """Result returned by a project-specific FLAC3D adapter.

    Parameters
    ----------
    point_ids
        Unique observation identifiers in the same row order as ``stress_pa``.
    stress_pa
        Native FLAC3D total-stress tensor components in Pa, ordered
        ``[sxx, syy, szz, sxy, syz, sxz]``. Compression must remain negative.
    converged
        True only if the project-selected equilibrium criterion is satisfied.
    solve_cycles
        Optional number of mechanical cycles.
    convergence_metric
        Optional final convergence measure (for example, a force ratio).
    metadata
        JSON-serializable non-confidential diagnostics.
    """

    point_ids: Sequence[str]
    stress_pa: np.ndarray
    converged: bool
    solve_cycles: Optional[int] = None
    convergence_metric: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        ids = [str(value) for value in self.point_ids]
        if not ids or any(not value for value in ids):
            raise ValueError("ForwardResult.point_ids must contain non-empty strings.")
        if len(set(ids)) != len(ids):
            raise ValueError("ForwardResult.point_ids must be unique.")
        stress = np.asarray(self.stress_pa, dtype=float)
        if stress.ndim != 2 or stress.shape != (len(ids), 6):
            raise ValueError("ForwardResult.stress_pa must have shape (n_points, 6).")
        if not np.isfinite(stress).all():
            raise ValueError("ForwardResult.stress_pa contains NaN or Inf.")
        if not bool(self.converged):
            raise ValueError("The adapter reported an unconverged forward solution.")
        if self.solve_cycles is not None and int(self.solve_cycles) < 0:
            raise ValueError("solve_cycles must be non-negative when supplied.")
        if self.convergence_metric is not None and not np.isfinite(self.convergence_metric):
            raise ValueError("convergence_metric must be finite when supplied.")


def utc_iso(epoch_seconds: Optional[float] = None) -> str:
    """Return an RFC-3339-like UTC timestamp without platform dependencies."""
    value = time.time() if epoch_seconds is None else float(epoch_seconds)
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(value))


def atomic_write_text(path: Path, text: str) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(str(tmp), str(path))


def atomic_write_json(path: Path, payload: Mapping[str, Any]) -> None:
    atomic_write_text(Path(path), json.dumps(payload, indent=2, sort_keys=True) + "\n")


def read_json(path: Path) -> Dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError("JSON root must be an object: {0}".format(path))
    return value


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def write_stress_csv(path: Path, point_ids: Sequence[str], stress_pa: np.ndarray) -> None:
    result = ForwardResult(point_ids=point_ids, stress_pa=stress_pa, converged=True)
    result.validate()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(STRESS_CSV_COLUMNS)
        for point_id, row in zip(result.point_ids, np.asarray(result.stress_pa, dtype=float)):
            writer.writerow([str(point_id)] + ["{0:.17g}".format(float(value)) for value in row])
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(str(tmp), str(path))


def read_stress_csv(path: Path) -> Tuple[List[str], np.ndarray]:
    point_ids: List[str] = []
    rows: List[List[float]] = []
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != STRESS_CSV_COLUMNS:
            raise ValueError(
                "Unexpected stress CSV columns. Expected {0}, received {1}.".format(
                    STRESS_CSV_COLUMNS, reader.fieldnames
                )
            )
        for record in reader:
            point_ids.append(record["point_id"])
            rows.append([float(record[name + "_pa"]) for name in STRESS_COMPONENTS])
    stress = np.asarray(rows, dtype=float)
    ForwardResult(point_ids=point_ids, stress_pa=stress, converged=True).validate()
    return point_ids, stress


def validate_request(request: Mapping[str, Any]) -> Dict[str, Any]:
    """Validate and normalize one immutable task request."""
    if request.get("protocol") != PROTOCOL_NAME:
        raise ValueError("Unsupported protocol name.")
    if request.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("Unsupported protocol schema version.")

    run_id = str(request.get("run_id", ""))
    if not run_id:
        raise ValueError("request.run_id is required.")

    parameters = request.get("parameters")
    if not isinstance(parameters, dict):
        raise ValueError("request.parameters must be an object.")
    if list(parameters.get("names", [])) != PARAMETER_NAMES:
        raise ValueError("The six parameter names or order do not match the protocol.")
    if list(parameters.get("units", [])) != PARAMETER_UNITS:
        raise ValueError("The six parameter units do not match the protocol.")
    values = np.asarray(parameters.get("values", []), dtype=float).reshape(-1)
    if values.size != 6 or not np.isfinite(values).all():
        raise ValueError("Exactly six finite inverse-parameter values are required.")
    if values[0] <= 0.0:
        raise ValueError("Gravity magnitude G must be positive.")

    software = request.get("software")
    if not isinstance(software, dict):
        raise ValueError("request.software must be an object.")
    if str(software.get("matlab", "")) != "R2022b":
        raise ValueError("The public hybrid implementation targets MATLAB R2022b.")
    if not str(software.get("flac3d", "")).startswith("7.0"):
        raise ValueError("The public hybrid implementation targets FLAC3D 7.0.")
    model_x_azimuth = float(request.get("model_x_azimuth_deg", float("nan")))
    if not np.isfinite(model_x_azimuth):
        raise ValueError("model_x_azimuth_deg must be finite.")

    if request.get("stress_sign_convention") != STRESS_SIGN_CONVENTION:
        raise ValueError("The request must use FLAC3D's native stress sign convention.")
    if request.get("stress_output_unit") != STRESS_UNIT:
        raise ValueError("The task output unit must be Pa.")
    if list(request.get("stress_component_order", [])) != STRESS_COMPONENTS:
        raise ValueError("The stress component order does not match the protocol.")
    if request.get("azimuth_convention") != AZIMUTH_CONVENTION:
        raise ValueError("The azimuth convention does not match the protocol.")

    point_ids = [str(value) for value in request.get("expected_point_ids", [])]
    if not point_ids or any(not value for value in point_ids):
        raise ValueError("expected_point_ids must contain non-empty strings.")
    if len(set(point_ids)) != len(point_ids):
        raise ValueError("expected_point_ids must be unique.")
    if int(request.get("expected_n_points", -1)) != len(point_ids):
        raise ValueError("expected_n_points does not equal the point-ID count.")

    profile = request.get("linear_profile")
    if not isinstance(profile, dict):
        raise ValueError("linear_profile must be an object.")
    z_top = float(profile.get("z_top_m", float("nan")))
    z_bottom = float(profile.get("z_bottom_m", float("nan")))
    if not np.isfinite(z_top) or not np.isfinite(z_bottom) or z_top <= z_bottom:
        raise ValueError("linear_profile requires finite z_top_m > z_bottom_m.")
    if not isinstance(profile.get("clip"), bool):
        raise ValueError("linear_profile.clip must be a JSON boolean.")

    model_hash = str(request.get("model_config_hash", "")).lower()
    if len(model_hash) != 64 or any(char not in "0123456789abcdef" for char in model_hash):
        raise ValueError("model_config_hash must be a 64-character SHA-256 hexadecimal string.")

    normalized = dict(request)
    normalized["run_id"] = run_id
    normalized["expected_point_ids"] = point_ids
    normalized["parameters"] = dict(parameters)
    normalized["parameters"]["values"] = values.tolist()
    normalized["model_config_hash"] = model_hash
    return normalized


def make_result_payload(
    request: Mapping[str, Any],
    status: str,
    worker_id: str,
    worker_version: str,
    started_epoch_s: float,
    finished_epoch_s: float,
    model_config_hash: str,
    stress_file: Optional[str] = None,
    stress_sha256: Optional[str] = None,
    forward_result: Optional[ForwardResult] = None,
    error_file: Optional[str] = None,
    error_type: Optional[str] = None,
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "protocol": PROTOCOL_NAME,
        "schema_version": SCHEMA_VERSION,
        "run_id": request["run_id"],
        "status": status,
        "worker_id": worker_id,
        "worker_version": worker_version,
        "started_epoch_s": float(started_epoch_s),
        "started_utc": utc_iso(started_epoch_s),
        "finished_epoch_s": float(finished_epoch_s),
        "finished_utc": utc_iso(finished_epoch_s),
        "elapsed_seconds": max(0.0, float(finished_epoch_s - started_epoch_s)),
        "model_config_hash": str(model_config_hash).lower(),
        "stress_sign_convention": STRESS_SIGN_CONVENTION,
        "stress_unit": STRESS_UNIT,
        "stress_component_order": STRESS_COMPONENTS,
    }
    if forward_result is not None:
        payload.update(
            {
                "converged": bool(forward_result.converged),
                "solve_cycles": forward_result.solve_cycles,
                "convergence_metric": forward_result.convergence_metric,
                "n_points": len(forward_result.point_ids),
                "stress_file": stress_file,
                "stress_sha256": stress_sha256,
                "adapter_metadata": forward_result.metadata,
            }
        )
    if error_file is not None:
        payload["error_file"] = error_file
    if error_type is not None:
        payload["error_type"] = error_type
    return payload
