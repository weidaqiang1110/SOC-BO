"""Persistent SOC-BO file-queue worker for the FLAC3D 7.0 Python console.

Environment variables
---------------------
SOCBO_EXCHANGE_DIR
    Root of the persistent task queue.
SOCBO_ADAPTER
    Import path in ``module:ClassName`` form.
SOCBO_HEARTBEAT_SECONDS
    Worker/lease heartbeat interval (default 5 s).
SOCBO_LEASE_SECONDS
    Lease duration refreshed by the heartbeat thread (default 60 s).
SOCBO_MAX_ATTEMPTS
    Maximum claims of one task, including the first attempt (default 2).
SOCBO_POLL_SECONDS
    Idle queue polling interval (default 0.5 s).
"""
from __future__ import annotations

import importlib
import os
from pathlib import Path
import platform
import threading
import time
import traceback
from typing import Any, Dict, Mapping, Optional
import uuid

import numpy as np

from .constants import PACKAGE_VERSION, PROTOCOL_NAME, SCHEMA_VERSION
from .protocol import (
    ForwardResult,
    atomic_write_json,
    atomic_write_text,
    make_result_payload,
    read_json,
    sha256_file,
    utc_iso,
    validate_request,
    write_stress_csv,
)


class TaskCancelled(RuntimeError):
    """Raised when a queued or running task has been cancelled."""


def _load_adapter(spec: str):
    if ":" not in spec:
        raise ValueError("SOCBO_ADAPTER must have form module:ClassName")
    module_name, class_name = spec.split(":", 1)
    cls = getattr(importlib.import_module(module_name), class_name)
    return cls()


def _safe_move_directory(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise FileExistsError("Destination already exists: {0}".format(destination))
    os.replace(str(source), str(destination))


class HeartbeatController:
    """Write worker status and refresh the active task lease in the background."""

    def __init__(
        self,
        root: Path,
        worker_id: str,
        worker_version: str,
        adapter_info: Mapping[str, Any],
        model_config_hash: str,
        heartbeat_seconds: float,
        lease_seconds: float,
    ) -> None:
        self.root = Path(root)
        self.worker_id = worker_id
        self.worker_version = worker_version
        self.adapter_info = dict(adapter_info)
        self.model_config_hash = str(model_config_hash).lower()
        self.heartbeat_seconds = float(heartbeat_seconds)
        self.lease_seconds = float(lease_seconds)
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._status = "starting"
        self._current_run_id: Optional[str] = None
        self._current_task_dir: Optional[Path] = None
        self._thread = threading.Thread(target=self._loop, name="socbo-heartbeat")
        self._thread.daemon = True

    @property
    def status_path(self) -> Path:
        return self.root / "workers" / ("worker_" + self.worker_id + ".json")

    def start(self) -> None:
        self._thread.start()

    def set_state(
        self, status: str, run_id: Optional[str] = None, task_dir: Optional[Path] = None
    ) -> None:
        with self._lock:
            self._status = str(status)
            self._current_run_id = run_id
            self._current_task_dir = Path(task_dir) if task_dir is not None else None
        self.write_now()

    def write_now(self) -> None:
        now = time.time()
        with self._lock:
            status = self._status
            run_id = self._current_run_id
            task_dir = self._current_task_dir
        payload = {
            "protocol": PROTOCOL_NAME,
            "schema_version": SCHEMA_VERSION,
            "worker_id": self.worker_id,
            "worker_version": self.worker_version,
            "status": status,
            "current_run_id": run_id,
            "heartbeat_epoch_s": now,
            "heartbeat_utc": utc_iso(now),
            "lease_seconds": self.lease_seconds,
            "python_version": platform.python_version(),
            "adapter_info": self.adapter_info,
            "model_config_hash": self.model_config_hash,
        }
        atomic_write_json(self.status_path, payload)
        if task_dir is not None and task_dir.is_dir():
            lease = {
                "protocol": PROTOCOL_NAME,
                "schema_version": SCHEMA_VERSION,
                "worker_id": self.worker_id,
                "run_id": run_id,
                "heartbeat_epoch_s": now,
                "heartbeat_utc": utc_iso(now),
                "lease_expires_epoch_s": now + self.lease_seconds,
            }
            # Do not call the general parent-creating atomic writer here: the
            # task directory may be moved to a terminal state between checks,
            # and a heartbeat must never recreate a ghost running directory.
            lease_path = task_dir / "lease.json"
            lease_tmp = task_dir / "lease.json.tmp"
            try:
                with lease_tmp.open("w", encoding="utf-8", newline="\n") as handle:
                    import json
                    handle.write(json.dumps(lease, indent=2, sort_keys=True) + "\n")
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(str(lease_tmp), str(lease_path))
            except (FileNotFoundError, NotADirectoryError):
                try:
                    lease_tmp.unlink()
                except FileNotFoundError:
                    pass

    def stop(self) -> None:
        self.set_state("stopped")
        self._stop.set()
        self._thread.join(timeout=max(2.0, 2.0 * self.heartbeat_seconds))

    def _loop(self) -> None:
        while not self._stop.wait(self.heartbeat_seconds):
            try:
                self.write_now()
            except Exception:
                # A heartbeat failure must not silently terminate the worker.
                traceback.print_exc()


class FileQueueWorker:
    """Single FLAC3D worker for the persistent task-directory protocol."""

    def __init__(
        self,
        root: Path,
        adapter: Any,
        heartbeat_seconds: float = 5.0,
        lease_seconds: float = 60.0,
        max_attempts: int = 2,
    ) -> None:
        self.root = Path(root).resolve()
        self.adapter = adapter
        self.heartbeat_seconds = float(heartbeat_seconds)
        self.lease_seconds = float(lease_seconds)
        self.max_attempts = int(max_attempts)
        if self.heartbeat_seconds <= 0.0:
            raise ValueError("heartbeat_seconds must be positive.")
        if self.lease_seconds <= 2.0 * self.heartbeat_seconds:
            raise ValueError("lease_seconds must exceed twice heartbeat_seconds.")
        if self.max_attempts < 1:
            raise ValueError("max_attempts must be at least one.")

        for name in (
            "queued",
            "running",
            "completed",
            "failed",
            "cancelled",
            "workers",
        ):
            (self.root / name).mkdir(parents=True, exist_ok=True)

        self.worker_id = str(uuid.uuid4())
        self.model_config_hash = str(self.adapter.model_config_hash()).lower()
        if len(self.model_config_hash) != 64:
            raise ValueError("Adapter model_config_hash() must return a SHA-256 hex string.")
        self.adapter_info = dict(self.adapter.software_info())
        self.heartbeat = HeartbeatController(
            root=self.root,
            worker_id=self.worker_id,
            worker_version=PACKAGE_VERSION,
            adapter_info=self.adapter_info,
            model_config_hash=self.model_config_hash,
            heartbeat_seconds=self.heartbeat_seconds,
            lease_seconds=self.lease_seconds,
        )

    def start(self) -> None:
        self.heartbeat.start()
        self.heartbeat.set_state("idle")
        self.recover_stale_tasks()

    def stop(self) -> None:
        self.heartbeat.stop()

    def recover_stale_tasks(self) -> None:
        """Requeue abandoned leased tasks or fail them after max attempts."""
        now = time.time()
        for task_dir in sorted((self.root / "running").iterdir()):
            if not task_dir.is_dir():
                continue
            lease_path = task_dir / "lease.json"
            lease_expiry = 0.0
            if lease_path.is_file():
                try:
                    lease_expiry = float(read_json(lease_path).get("lease_expires_epoch_s", 0.0))
                except Exception:
                    lease_expiry = 0.0
            if lease_expiry > now:
                continue
            try:
                if (task_dir / "CANCEL").exists():
                    self._finalize_cancelled(
                        task_dir, "Cancelled while recovering a stale task."
                    )
                    continue
                attempts = self._read_attempt_count(task_dir)
                if attempts >= self.max_attempts:
                    self._finalize_failure(
                        task_dir,
                        RuntimeError(
                            "Task lease expired after the maximum number of attempts."
                        ),
                        started_epoch_s=now,
                    )
                else:
                    try:
                        (task_dir / "lease.json").unlink()
                    except FileNotFoundError:
                        pass
                    _safe_move_directory(task_dir, self.root / "queued" / task_dir.name)
            except (FileNotFoundError, FileExistsError):
                # Another worker may have recovered or claimed the task first.
                continue

    def run_once(self) -> bool:
        """Claim and process at most one task. Return True if one was claimed."""
        task_dir = self._claim_next_task()
        if task_dir is None:
            return False
        self._process_claimed_task(task_dir)
        return True

    def _claim_next_task(self) -> Optional[Path]:
        for queued in sorted((self.root / "queued").iterdir()):
            if not queued.is_dir() or not (queued / "READY").is_file():
                continue
            if (queued / "CANCEL").is_file():
                self._finalize_cancelled(queued, "Cancelled before task claim.")
                continue
            running = self.root / "running" / queued.name
            try:
                _safe_move_directory(queued, running)
            except FileNotFoundError:
                continue
            except FileExistsError:
                continue
            attempts = self._read_attempt_count(running) + 1
            claimed_now = time.time()
            atomic_write_json(
                running / "attempt.json",
                {"attempt": attempts, "claimed_epoch_s": claimed_now, "worker_id": self.worker_id},
            )
            # Establish a lease immediately at claim time, before the regular
            # heartbeat thread is pointed at this task. This closes the small
            # multi-worker recovery window between directory claim and solve.
            atomic_write_json(
                running / "lease.json",
                {
                    "protocol": PROTOCOL_NAME,
                    "schema_version": SCHEMA_VERSION,
                    "worker_id": self.worker_id,
                    "run_id": running.name,
                    "heartbeat_epoch_s": claimed_now,
                    "heartbeat_utc": utc_iso(claimed_now),
                    "lease_expires_epoch_s": claimed_now + self.lease_seconds,
                },
            )
            if attempts > self.max_attempts:
                self._finalize_failure(
                    running,
                    RuntimeError("Task exceeded the configured maximum claim count."),
                    started_epoch_s=time.time(),
                )
                continue
            return running
        return None

    @staticmethod
    def _read_attempt_count(task_dir: Path) -> int:
        path = Path(task_dir) / "attempt.json"
        if not path.is_file():
            return 0
        try:
            return int(read_json(path).get("attempt", 0))
        except Exception:
            return 0

    def _process_claimed_task(self, task_dir: Path) -> None:
        started = time.time()
        run_id = task_dir.name
        self.heartbeat.set_state("busy", run_id=run_id, task_dir=task_dir)
        try:
            request = validate_request(read_json(task_dir / "request.json"))
            if request["run_id"] != run_id:
                raise ValueError("Task-directory name and request.run_id do not match.")
            if request["model_config_hash"] != self.model_config_hash:
                raise ValueError(
                    "MATLAB and FLAC3D model_config_hash values do not match."
                )
            if self._cancel_requested(task_dir):
                raise TaskCancelled("Task cancelled before forward evaluation.")

            result = self.adapter.evaluate(
                request,
                lambda: self._cancel_requested(task_dir),
                self.heartbeat.write_now,
            )
            if not isinstance(result, ForwardResult):
                raise TypeError("Adapter.evaluate must return protocol.ForwardResult.")
            result.validate()
            if self._cancel_requested(task_dir):
                raise TaskCancelled("Task cancelled during forward evaluation.")
            result = self._reorder_result(result, request["expected_point_ids"])

            stress_path = task_dir / "stress.csv"
            write_stress_csv(stress_path, result.point_ids, result.stress_pa)
            digest = sha256_file(stress_path)
            finished = time.time()
            payload = make_result_payload(
                request=request,
                status="succeeded",
                worker_id=self.worker_id,
                worker_version=PACKAGE_VERSION,
                started_epoch_s=started,
                finished_epoch_s=finished,
                model_config_hash=self.model_config_hash,
                stress_file="stress.csv",
                stress_sha256=digest,
                forward_result=result,
            )
            atomic_write_json(task_dir / "result.json", payload)
            self.heartbeat.set_state("finalizing", run_id=run_id, task_dir=None)
            _safe_move_directory(task_dir, self.root / "completed" / run_id)
        except TaskCancelled as exc:
            self.heartbeat.set_state("finalizing", run_id=run_id, task_dir=None)
            self._finalize_cancelled(task_dir, str(exc), started_epoch_s=started)
        except Exception as exc:
            self.heartbeat.set_state("finalizing", run_id=run_id, task_dir=None)
            self._finalize_failure(task_dir, exc, started_epoch_s=started)
        finally:
            self.heartbeat.set_state("idle")

    @staticmethod
    def _cancel_requested(task_dir: Path) -> bool:
        return (Path(task_dir) / "CANCEL").is_file()

    @staticmethod
    def _reorder_result(result: ForwardResult, expected_ids) -> ForwardResult:
        result_ids = [str(value) for value in result.point_ids]
        expected = [str(value) for value in expected_ids]
        if set(result_ids) != set(expected) or len(result_ids) != len(expected):
            raise ValueError("Adapter point IDs do not exactly match expected_point_ids.")
        index = {point_id: i for i, point_id in enumerate(result_ids)}
        order = [index[point_id] for point_id in expected]
        return ForwardResult(
            point_ids=expected,
            stress_pa=np.asarray(result.stress_pa, dtype=float)[order, :],
            converged=result.converged,
            solve_cycles=result.solve_cycles,
            convergence_metric=result.convergence_metric,
            metadata=result.metadata,
        )

    def _finalize_failure(
        self, task_dir: Path, exc: BaseException, started_epoch_s: float
    ) -> None:
        task_dir = Path(task_dir)
        run_id = task_dir.name
        request: Dict[str, Any]
        try:
            request = validate_request(read_json(task_dir / "request.json"))
        except Exception:
            request = {
                "run_id": run_id,
                "protocol": PROTOCOL_NAME,
                "schema_version": SCHEMA_VERSION,
            }
        error_text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        atomic_write_text(task_dir / "error.txt", error_text)
        payload = make_result_payload(
            request=request,
            status="failed",
            worker_id=self.worker_id,
            worker_version=PACKAGE_VERSION,
            started_epoch_s=started_epoch_s,
            finished_epoch_s=time.time(),
            model_config_hash=self.model_config_hash,
            error_file="error.txt",
            error_type=type(exc).__name__,
        )
        atomic_write_json(task_dir / "result.json", payload)
        destination = self.root / "failed" / run_id
        if task_dir.parent == destination.parent:
            return
        _safe_move_directory(task_dir, destination)

    def _finalize_cancelled(
        self,
        task_dir: Path,
        message: str,
        started_epoch_s: Optional[float] = None,
    ) -> None:
        task_dir = Path(task_dir)
        run_id = task_dir.name
        started = time.time() if started_epoch_s is None else float(started_epoch_s)
        try:
            request = validate_request(read_json(task_dir / "request.json"))
        except Exception:
            request = {
                "run_id": run_id,
                "protocol": PROTOCOL_NAME,
                "schema_version": SCHEMA_VERSION,
            }
        atomic_write_text(task_dir / "cancelled.txt", message + "\n")
        payload = make_result_payload(
            request=request,
            status="cancelled",
            worker_id=self.worker_id,
            worker_version=PACKAGE_VERSION,
            started_epoch_s=started,
            finished_epoch_s=time.time(),
            model_config_hash=self.model_config_hash,
            error_file="cancelled.txt",
            error_type="TaskCancelled",
        )
        atomic_write_json(task_dir / "result.json", payload)
        destination = self.root / "cancelled" / run_id
        if task_dir.parent == destination.parent:
            return
        _safe_move_directory(task_dir, destination)


def run_forever(poll_seconds: Optional[float] = None) -> None:
    root = Path(os.environ.get("SOCBO_EXCHANGE_DIR", "socbo_exchange")).resolve()
    adapter_spec = os.environ.get(
        "SOCBO_ADAPTER", "socbo_flac3d.project_adapter_template:ProjectAdapter"
    )
    adapter = _load_adapter(adapter_spec)
    heartbeat_seconds = float(os.environ.get("SOCBO_HEARTBEAT_SECONDS", "5"))
    lease_seconds = float(os.environ.get("SOCBO_LEASE_SECONDS", "60"))
    max_attempts = int(os.environ.get("SOCBO_MAX_ATTEMPTS", "2"))
    if poll_seconds is None:
        poll_seconds = float(os.environ.get("SOCBO_POLL_SECONDS", "0.5"))
    if poll_seconds <= 0.0:
        raise ValueError("poll_seconds must be positive.")

    worker = FileQueueWorker(
        root=root,
        adapter=adapter,
        heartbeat_seconds=heartbeat_seconds,
        lease_seconds=lease_seconds,
        max_attempts=max_attempts,
    )
    worker.start()
    print("SOC-BO v{0} worker {1} watching {2}".format(PACKAGE_VERSION, worker.worker_id, root))
    try:
        while True:
            processed = worker.run_once()
            if not processed:
                time.sleep(poll_seconds)
    except KeyboardInterrupt:
        print("SOC-BO worker stopping.")
    finally:
        worker.stop()


if __name__ == "__main__":
    run_forever()
