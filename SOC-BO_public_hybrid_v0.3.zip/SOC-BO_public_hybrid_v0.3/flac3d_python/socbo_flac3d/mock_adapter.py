"""Deterministic, non-scientific adapter used only for protocol smoke tests."""
from __future__ import annotations

from typing import Any, Callable, Dict, Mapping

import numpy as np

from .loading import SixParameterLoading
from .protocol import ForwardResult


class MockAdapter:
    """Return native FLAC3D signed stresses without using project data."""

    def __init__(self) -> None:
        self._model_hash = "a" * 64

    def model_config_hash(self) -> str:
        return self._model_hash

    def software_info(self) -> Dict[str, str]:
        return {"flac3d": "7.0-mock", "adapter": "MockAdapter"}

    def evaluate(
        self,
        request: Mapping[str, Any],
        cancel_requested: Callable[[], bool],
        keepalive: Callable[[], None],
    ) -> ForwardResult:
        if cancel_requested():
            raise RuntimeError("Task cancelled before mock evaluation.")
        keepalive()
        load = SixParameterLoading.from_array(request["parameters"]["values"])
        point_ids = list(request["expected_point_ids"])
        rows = []
        for i, _ in enumerate(point_ids):
            # Negative normal components represent compression in FLAC3D.
            rows.append(
                [
                    1.0e6 * (load.sx_uniform_mpa + 0.5 * load.sx_linear_mpa - i),
                    1.0e6 * (load.sy_uniform_mpa + 0.5 * load.sy_linear_mpa),
                    -1.0e6 * (8.0 + 0.1 * load.gravity_m_s2),
                    1.0e6 * load.sxy_mpa,
                    0.0,
                    0.0,
                ]
            )
        return ForwardResult(
            point_ids=point_ids,
            stress_pa=np.asarray(rows, dtype=float),
            converged=True,
            solve_cycles=10,
            convergence_metric=1.0e-6,
            metadata={"purpose": "protocol smoke test only"},
        )
