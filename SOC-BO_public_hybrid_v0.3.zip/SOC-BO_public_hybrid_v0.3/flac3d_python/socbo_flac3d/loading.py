"""Six-parameter loading helpers using native FLAC3D stress signs.

Inverse vector
--------------
``[G, SX_uniform, SY_uniform, SX_linear, SY_linear, SXY]``

``G`` is a positive gravity magnitude in m/s². Every stress parameter is in
MPa and follows FLAC3D's native tensor convention: tension positive and
compression negative. Therefore, a compressive horizontal normal stress and a
downward increase in compression are normally represented by negative uniform
and negative linear-increment values, respectively.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple, Union

import numpy as np


@dataclass(frozen=True)
class SixParameterLoading:
    gravity_m_s2: float
    sx_uniform_mpa: float
    sy_uniform_mpa: float
    sx_linear_mpa: float
    sy_linear_mpa: float
    sxy_mpa: float

    @classmethod
    def from_array(cls, parameters: np.ndarray) -> "SixParameterLoading":
        x = np.asarray(parameters, dtype=float).reshape(-1)
        if x.size != 6:
            raise ValueError(
                "The inverse vector must contain six values in the order "
                "[G,SX_uniform,SY_uniform,SX_linear,SY_linear,SXY]."
            )
        if not np.isfinite(x).all():
            raise ValueError("Inverse parameters contain NaN or Inf.")
        if x[0] <= 0.0:
            raise ValueError("Gravity magnitude G must be positive.")
        return cls(*[float(value) for value in x])


def normalized_depth(
    z: Union[np.ndarray, float], z_top: float, z_bottom: float, clip: bool = True
) -> np.ndarray:
    """Return ``xi=(z_top-z)/(z_top-z_bottom)``."""
    if not np.isfinite(z_top) or not np.isfinite(z_bottom) or z_top <= z_bottom:
        raise ValueError("Require finite z_top > z_bottom.")
    zz = np.asarray(z, dtype=float)
    if not np.isfinite(zz).all():
        raise ValueError("z contains NaN or Inf.")
    xi = (z_top - zz) / (z_top - z_bottom)
    return np.clip(xi, 0.0, 1.0) if clip else xi


def flac_native_profile_mpa(
    z: Union[np.ndarray, float],
    uniform_mpa: float,
    linear_increment_mpa: float,
    z_top: float,
    z_bottom: float,
    clip: bool = True,
) -> np.ndarray:
    """Evaluate a FLAC-native signed stress profile in MPa.

    ``sigma(z) = sigma_uniform + delta_sigma_linear * xi(z)``.
    """
    if not np.isfinite(uniform_mpa) or not np.isfinite(linear_increment_mpa):
        raise ValueError("Stress-profile parameters must be finite.")
    return uniform_mpa + linear_increment_mpa * normalized_depth(
        z, z_top, z_bottom, clip
    )


def flac_base_gradient_pa(
    uniform_mpa: float,
    linear_increment_mpa: float,
    z_top: float,
    z_bottom: float,
) -> Tuple[float, float]:
    """Return native FLAC3D ``base + gradient_z*z`` coefficients.

    No sign reversal is performed. Over ``z_bottom <= z <= z_top``:

    ``sigma(z) = base_pa + gradient_z_pa_per_m*z``

    is exactly equal to

    ``1e6*(uniform_mpa + linear_increment_mpa*(z_top-z)/(z_top-z_bottom))``.
    """
    if not np.isfinite(uniform_mpa) or not np.isfinite(linear_increment_mpa):
        raise ValueError("Stress-profile parameters must be finite.")
    if not np.isfinite(z_top) or not np.isfinite(z_bottom) or z_top <= z_bottom:
        raise ValueError("Require finite z_top > z_bottom.")
    dz = z_top - z_bottom
    gradient = -1.0e6 * linear_increment_mpa / dz
    base = 1.0e6 * (uniform_mpa + linear_increment_mpa * z_top / dz)
    return float(base), float(gradient)
