"""Deterministic SHA-256 manifest helpers for private forward configurations."""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Iterable, Optional


def hash_files(paths: Iterable[Path], root: Optional[Path] = None) -> str:
    """Hash file labels, sizes, and contents in deterministic sorted order.

    Parameters
    ----------
    paths
        Files defining the forward map (for example, base save file, private
        adapter, boundary-group manifest, and point map).
    root
        Optional root used to form stable relative labels. If omitted, only
        file names are used; duplicate names are then rejected.
    """
    files = [Path(value).resolve() for value in paths]
    if not files:
        raise ValueError("At least one model/config file is required.")
    for path in files:
        if not path.is_file():
            raise FileNotFoundError(str(path))
    root_path = Path(root).resolve() if root is not None else None
    labelled = []
    for path in files:
        if root_path is None:
            label = path.name
        else:
            try:
                label = path.relative_to(root_path).as_posix()
            except ValueError as exc:
                raise ValueError("Every file must lie below root.") from exc
        labelled.append((label, path))
    labelled.sort(key=lambda item: item[0])
    labels = [item[0] for item in labelled]
    if len(labels) != len(set(labels)):
        raise ValueError("Model/config file labels must be unique.")

    digest = hashlib.sha256()
    for label, path in labelled:
        encoded = label.encode("utf-8")
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)
        digest.update(path.stat().st_size.to_bytes(16, "big"))
        with path.open("rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
    return digest.hexdigest()
