"""Private FLAC3D 7.0 project-adapter template for SOC-BO v0.3.

Copy this file outside the public repository and implement the marked project
hooks. Never commit confidential model paths, coordinates, groups, or field
measurements.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, Mapping, Sequence

import numpy as np

from socbo_flac3d.loading import SixParameterLoading, flac_base_gradient_pa
from socbo_flac3d.protocol import ForwardResult


class ProjectAdapter:
    """Map one validated task request to native FLAC3D stress tensors."""

    def __init__(self) -> None:
        try:
            import itasca as it  # type: ignore
        except ImportError as exc:
            raise RuntimeError("ProjectAdapter must run inside FLAC3D 7.0 Python.") from exc
        self.it = it
        self.it.command("python-reset-state false")

    def model_config_hash(self) -> str:
        """Return the private model/configuration SHA-256 identifier.

        The value must match ``cfg.forward.model_config_hash`` in MATLAB. It
        should be recomputed whenever the restored model, loading groups,
        observation-point mapping, or material configuration changes.
        """
        raise NotImplementedError

    def software_info(self) -> Dict[str, str]:
        """Return non-confidential software/adapter metadata."""
        return {"flac3d": "7.0", "adapter": self.__class__.__name__}

    def evaluate(
        self,
        request: Mapping[str, Any],
        cancel_requested: Callable[[], bool],
        keepalive: Callable[[], None],
    ) -> ForwardResult:
        load = SixParameterLoading.from_array(request["parameters"]["values"])
        profile = request["linear_profile"]
        z_top_m = float(profile["z_top_m"])
        z_bottom_m = float(profile["z_bottom_m"])

        self.restore_and_configure_model()
        if cancel_requested():
            raise RuntimeError("Task cancelled before loading was applied.")
        self.apply_candidate(load, z_top_m, z_bottom_m)
        solve_info = self.solve_and_verify(cancel_requested, keepalive)
        if cancel_requested():
            raise RuntimeError("Task cancelled after the FLAC3D solve.")

        expected_ids = list(request["expected_point_ids"])
        stress_pa = np.asarray(
            self.extract_stress_components_pa(expected_ids), dtype=float
        )
        result = ForwardResult(
            point_ids=expected_ids,
            stress_pa=stress_pa,
            converged=bool(solve_info.get("converged", False)),
            solve_cycles=solve_info.get("solve_cycles"),
            convergence_metric=solve_info.get("convergence_metric"),
            metadata=dict(solve_info.get("metadata", {})),
        )
        result.validate()
        return result

    def restore_and_configure_model(self) -> None:
        """Restore the confidential base model and reset model state."""
        raise NotImplementedError

    def apply_candidate(
        self, load: SixParameterLoading, z_top_m: float, z_bottom_m: float
    ) -> None:
        """Apply the six parameters without any stress-sign reversal.

        The inverse stress parameters already follow FLAC3D's native convention
        (tension positive, compression negative). For the two normal profiles,

        ``sigma_X(z)=SX_uniform+SX_linear*(z_top-z)/(z_top-z_bottom)``

        and analogously for Y. The helper returns Pa coefficients for a
        ``base + gradient-z*z`` command representation. ``SXY`` is a native
        signed tensor shear component and ``G`` is applied as gravity
        ``(0,0,-G)``.
        """
        sx_base_pa, sx_gradient_pa_per_m = flac_base_gradient_pa(
            load.sx_uniform_mpa,
            load.sx_linear_mpa,
            z_top_m,
            z_bottom_m,
        )
        sy_base_pa, sy_gradient_pa_per_m = flac_base_gradient_pa(
            load.sy_uniform_mpa,
            load.sy_linear_mpa,
            z_top_m,
            z_bottom_m,
        )
        sxy_pa = load.sxy_mpa * 1.0e6
        gravity_z = -load.gravity_m_s2

        # PROJECT-SPECIFIC: use these native FLAC3D quantities in the exact
        # boundary groups and command syntax of the confidential model.
        _ = (
            sx_base_pa,
            sx_gradient_pa_per_m,
            sy_base_pa,
            sy_gradient_pa_per_m,
            sxy_pa,
            gravity_z,
        )
        raise NotImplementedError(
            "Apply native signed X/Y profile tractions, one native signed SXY "
            "component, and model gravity (0,0,-G)."
        )

    def solve_and_verify(
        self,
        cancel_requested: Callable[[], bool],
        keepalive: Callable[[], None],
    ) -> Dict[str, Any]:
        """Solve in chunks when possible and return convergence diagnostics.

        A robust private implementation must solve in bounded chunks when
        possible, periodically call ``keepalive()`` to renew the task lease,
        and call ``cancel_requested()`` between chunks. Return, for example:

        ``{"converged": True, "solve_cycles": 100000,``
        `` "convergence_metric": 8.0e-6, "metadata": {...}}``.
        """
        raise NotImplementedError

    def extract_stress_components_pa(
        self, expected_point_ids: Sequence[str]
    ) -> np.ndarray:
        """Return native total stresses in Pa for the requested point IDs.

        The exact output order is ``[sxx,syy,szz,sxy,syz,sxz]``, matching the
        documented FLAC3D tensor ordering. Do not multiply the tensor by -1 and
        do not alter the sign of individual shear components.
        """
        raise NotImplementedError
