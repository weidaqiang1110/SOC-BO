"""Shared constants for the SOC-BO v0.3 task protocol."""

PACKAGE_VERSION = "0.3.0"
PROTOCOL_NAME = "SOCBO_FILE_QUEUE"
SCHEMA_VERSION = "1.0"

PARAMETER_NAMES = [
    "G",
    "SX_uniform",
    "SY_uniform",
    "SX_linear",
    "SY_linear",
    "SXY",
]
PARAMETER_UNITS = ["m/s2", "MPa", "MPa", "MPa", "MPa", "MPa"]

STRESS_COMPONENTS = ["sxx", "syy", "szz", "sxy", "syz", "sxz"]
STRESS_CSV_COLUMNS = ["point_id"] + [name + "_pa" for name in STRESS_COMPONENTS]
STRESS_UNIT = "Pa"
STRESS_SIGN_CONVENTION = "tension_positive_compression_negative"
AZIMUTH_CONVENTION = "clockwise_from_geographic_north_axial_180_deg"
