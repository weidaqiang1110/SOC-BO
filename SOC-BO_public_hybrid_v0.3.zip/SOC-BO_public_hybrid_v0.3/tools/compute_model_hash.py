#!/usr/bin/env python
"""Compute the v0.3 private model/config SHA-256 identifier."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "flac3d_python"))
from socbo_flac3d.model_hash import hash_files  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("files", nargs="+", type=Path)
    parser.add_argument("--root", type=Path, default=None)
    args = parser.parse_args()
    print(hash_files(args.files, root=args.root))


if __name__ == "__main__":
    main()
