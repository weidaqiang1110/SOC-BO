%% PIBO_MultiConstraint_Boreholes.m

clear; clc; close all;
delete 'run_simulation.txt'
delete 'simulation_completed.txt'
rng(1)

%%==========================================================
% 1. 问题定义与数据分组
%===========================================================
fprintf('>>> [Step 1] 初始化任务...\n')

n_boreholes = 5;     % 钻孔数量
points_per_bh = 3;   % 每个钻孔测点数量
total_points = n_boreholes * points_per_bh;  % 总测量数量

obs_stress = csvread('K2 meastress-HS2.csv');
obs_stress_mat = reshape(obs_stress', [], total_points)';
obs_stress_mat = [obs_stress_mat, zeros(size(obs_stress_mat,1),2)];
disp('obs stress mat: ')
disp(obs_stress_mat);

% 实测主应力方向
obs_azimuths = csvread('obs_azimuths.csv');
disp('obs_azi: ')
disp(obs_azimuths');   % 输出一行

% 权重分配
weights = [1,1,1,0.75,0.75,0.75,1,1,1,1,1,1,1,1,1];
fprintf('权重维度为： %d\n', length(weights));
weights = weights / sum(weights);   % 归一化

% 封装观察数据结构体
obs_data.stress_mat = obs_stress_mat;
obs_data.azimuths = obs_azimuths;
obs_data.weights = weights;

% 定义每个测点属于哪个钻孔
obs_data.bh_idx = reshape(repmat(1:n_boreholes, points_per_bh, 1), [], 1);
obs_data.n_boreholes = n_boreholes;

fprintf('钻孔数量： %d | 总测点数： %d\n', n_boreholes, total_points);


%% ==========================================================
% 2. 算法配置
% ===========================================================
n_dims = 7;   
cfg.n_init = 20;
cfg.n_iter = 80;
cfg.bounds = [...
    8.0,  8.0,  3.0,  4.0,  1.0,  0.0,  0.0;
    11.0, 16.0, 15.0, 22.0, 16.0, 1.9,  1.9];

% 约束算法
cfg.tol_init_guess = [15.0, 15.0, 15.0, 15.0, 20.0];
cfg.tol_final = [15.0, 15.0, 15.0, 15.0, 20.0];
cfg.decay_rate = 5.0;

% 退火策略
cfg.beta_start = 0.3;
cfg.anneal_slope = 10;


%% 初始采样
fprintf('\n>>> [step 2] 初始采样...\n');
%X = lhsdesign(cfg.n_init, n_dims) .* (cfg.bounds(2,:) - cfg.bounds(1,:))...
   + cfg.bounds(1,:);
X=csvread('x_6.csv');
Y_TRMF = zeros(cfg.n_init, 1);
Y_RMSE_BH = zeros(cfg.n_init, n_boreholes);

for i=1: cfg.n_init
    fprintf('\n>>> 第%d次初始采样\n', i);
    disp(X(i,:));
    [sim_mat,sim_azi] = run_flac3d_simulation(X(i,:), total_points);
    constrast_mat = [obs_data.stress_mat(:,1) sim_mat(:,1)...
         obs_data.stress_mat(:,2) sim_mat(:,2)...
         obs_data.stress_mat(:,3) sim_mat(:,3)...
         obs_data.stress_mat(:,4) sim_mat(:,4)...
         obs_data.stress_mat(:,5) sim_mat(:,5)...
         obs_data.stress_mat(:,6) sim_mat(:,6)]
    disp('sim_azi: \n')
    disp(sim_azi)

    % 计算全局TRMF
    Y_TRMF(i) = compute_TRMF_4_scalar(sim_mat, obs_data.stress_mat, obs_data.weights);
    
    % 计算每个钻孔的独立RMSE
    rmse_vec = compute_borehole_rmses(sim_mat, obs_data.azimuths, obs_data.bh_idx);
    Y_RMSE_BH(i,:) = rmse_vec;

    rmse_ini_str = sprintf('%.1f ', rmse_vec);
    fprintf('Iter %2d | Loss: %.4f | BH_RMSEs: [%s]\n', ...
        i, Y_TRMF(i), rmse_ini_str);
end

% 自适应初始容忍度（取所有钻孔误差中位数的最大值，保证起步不卡死）
%init_tol_adaptive = median(max(Y_RMSE_BH, [], 2));
init_tol_adaptive = median(Y_RMSE_BH, 1);
%cfg.tol_init = max(cfg.tol_init_guess, init_tol_adaptive);
cfg.tol_init = cfg.tol_init_guess;


fprintf('init tol: [%.1f, %.1f, %.1f, %.1f, %.1f]\n',cfg.tol_init);

history.loss = [Y_TRMF; zeros(cfg.n_init, 1)];
history.rmse_bh = [Y_RMSE_BH; zeros(cfg.n_iter, n_boreholes)];
history.tol_matrix = zeros(cfg.n_init + cfg.n_iter, n_boreholes);    

%% 多约束贝叶斯优化主循环
fprintf('\n>>> [Step 3] 进入多约束PIBO主循环...\n');

for k = 1:cfg.n_iter
    idx = cfg.n_init + k;
    progress = (k-1) / cfg.n_iter;

    % 更新参数策略
    curr_tol = cfg.tol_final + (cfg.tol_init - cfg.tol_final) * ...
        exp (-cfg.decay_rate * progress);
    history.tol_matrix(idx, :) = curr_tol;
    
    sigmoid = 1 / (1 + exp(-cfg.anneal_slope * (progress - 0.5)));
    curr_beta = cfg.beta_start + (1.0 - cfg.beta_start) * sigmoid;

    % 训练GP群（1个GP目标+M个约束GP）
    gp_obj = fitrgp(X, Y_TRMF, 'KernelFunction', 'matern52', ...
        'Standardize',true);

    % 约束GPs （用Cell数组存储）
    gp_cons = cell(n_boreholes, 1);
    for b = 1:n_boreholes
        % 训练第b个钻孔的误差模型
        % 注意使用SigmaLowerBound防止过拟合
        gp_cons{b} = fitrgp(X, Y_RMSE_BH(:, b), 'KernelFunction', 'matern52',...
            'Standardize', true, 'SigmaLowerBound', 1e-3);
    end

    % 采集函数优化
    x_new = optimization_acq_multi_constraint(gp_obj, gp_cons, curr_tol, curr_beta,...
        cfg.bounds, min(Y_TRMF));
    disp(x_new);

    % 模拟与评估
    [sim_mat_new, sim_azi] = run_flac3d_simulation(x_new, total_points);
    constrast_mat = [obs_data.stress_mat(:,1) sim_mat_new(:,1)...
        obs_data.stress_mat(:,2) sim_mat_new(:,2)...
        obs_data.stress_mat(:,3) sim_mat_new(:,3)...
        obs_data.stress_mat(:,4) sim_mat_new(:,4)...
        obs_data.stress_mat(:,5) sim_mat_new(:,5)...
        obs_data.stress_mat(:,6) sim_mat_new(:,6)]
    disp('sim_azi: \n')
    disp(sim_azi)

    loss_new = compute_TRMF_4_scalar(sim_mat_new, obs_data.stress_mat, obs_data.weights);
    rmse_vec_new = compute_borehole_rmses(sim_mat_new, obs_data.azimuths, obs_data.bh_idx);

    % 更新
    X = [X; x_new];
    Y_TRMF = [Y_TRMF; loss_new]
    Y_RMSE_BH = [Y_RMSE_BH; rmse_vec_new]
    history.loss(idx) = loss_new;
    history.rmse_bh(idx, :) = rmse_vec_new;

    rmse_str = sprintf('%.1f ', rmse_vec_new);
    fprintf('Iter %2d | Tol: [%.1f, %.1f, %.1f, %.1f, %.1f] | Loss: %.4f | BH_RMSEs: [%s]\n', ...
        k, curr_tol, loss_new, rmse_str);
end



