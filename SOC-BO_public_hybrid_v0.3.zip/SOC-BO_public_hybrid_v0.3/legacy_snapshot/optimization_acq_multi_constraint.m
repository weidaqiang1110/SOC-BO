function x_best = optimization_acq_multi_constraint(gp_obj, gp_cons, tol, beta, bounds, y_best)
    % 混合优化策略 （GA + SQP）
    n_vars = size(bounds, 2);

    % 适应度函数-EIC
    fitness_fcn = @(x) -1 * eval_multi_eic(x, gp_obj, gp_cons, tol, beta, y_best);

    % 适应度函数-EI
    %fitness_fcn = @(x) -1 * eval_multi_ei(x, gp_obj, gp_cons, tol, beta, y_best);

    % GA
    %opts_ga = optimoptions('ga', 'Display', 'off', 'PopulationSize', 100,...
    %   'MaxGenerations', 50);

    opts_ga = optimoptions('ga', 'Display', 'off', 'PopulationSize', 100,...
        'MaxGenerations', 50);
    [x_ga, ~] = ga(fitness_fcn, n_vars, [], [], [], [], bounds(1,:), bounds(2,:),...
        [], opts_ga);

    % SQP精修
    try
        x_best = fmincon(fitness_fcn, x_ga, [], [], [], [], bounds(1,:), bounds(2,:),...
            optimoptions('fmincon', 'Display', 'off'));

    catch
        x_best = x_ga;
    end
end


