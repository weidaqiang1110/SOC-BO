% RMSE计算
function rmse = compute_rmse_from_matrix(sim_mat, obs_az, weights)
    diff_sq = 0; 
    n = size(sim_mat, 1);

    for i = 1:n
        sxx=sim_mat(i, 1); 
        syy = sim_mat(i,2); 
        txy=sim_mat(i,4);

        [V, D]=eig([sxx txy; txy syy]); 
        [~, id] = max(diag(D)); 
        v=V(:,id);
        azi_sim = mod(rad2deg(atan2(v(2),v(1))),180);

        azi_obs = obs_az(i);

        u_s=[cosd(2*azi_sim); sind(2*azi_sim)]; u_o=[cosd(2*obs_az(i)); sind(2*obs_az(i))];
        delta=rad2deg(acos(max(min(dot(u_s,u_o),1),-1)))/2;
        diff_sq=diff_sq+weights(i)*delta^2;
    end
    rmse = sqrt(diff_sq/sum(weights));
end
