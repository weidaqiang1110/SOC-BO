function total_loss = compute_TRMF_4(sim_mat, obs_mat, weights)
    % 输入: sim_mat, obs_mat 均为 [n_points x 6]
    % 列顺序: sxx, syy, szz, sxy, syz, sxz
    % 计算加权归一化 Frobenius 范数
    
    sim_mat_4 = sim_mat(:,1:4);
    obs_mat_4 = obs_mat(:,1:4);
    total_loss = 0;
    n_points = size(sim_mat, 1);
    for i = 1:n_points
        % Extract the six components of the current row
        v_sim = sim_mat_4(i,:);
        v_obs = obs_mat_4(i,:);
        
        diff_4 = v_sim - v_obs;
        
        % Calculate the relative error
        misfit = norm(diff_4, 'fro') / norm(v_obs, 'fro');
        total_loss = total_loss + weights(i) * misfit;
        
    end
end