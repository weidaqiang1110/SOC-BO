% 计算分钻孔RMSE
function rmse_vec = compute_borehole_rmses(sim_mat, obs_az, bh_idx)
    % 输出： [1 X N_boreholes] 的向量
    unique_bhs = unique(bh_idx);
    n_bhs = length(unique_bhs);
    fprintf('钻孔数量为： %d\n', n_bhs);
    rmse_vec = zeros(1, n_bhs);

    for b = 1:n_bhs
        % 提取属于该钻孔的索引
        idx = find(bh_idx == unique_bhs(b));

        % 提取子集数据
        sub_sim =sim_mat(idx, :);
        sub_obs_az = obs_az(idx);

        % 局部权重(简单平均）
        w = ones(length(idx), 1) / length(idx);

        % 调用之前写好的RMSE计算函数
        rmse_vec(b) = compute_rmse_from_matrix(sub_sim, sub_obs_az, w);
    end
    disp('钻孔方向rmse：\n')
    rmse_vec
end

