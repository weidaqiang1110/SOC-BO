import numpy as np

def calc_SH_azimuth_from_stress(flat_stress):
    """
    计算 n 个点的最大水平主应力与模型坐标系 x 轴的夹角

    Parameters
    ----------
    flat_stress : array-like
        一维数组，长度为 6*n
        应力分量顺序为：
        [sxx, syy, szz, sxy, syz, sxz] * n

    Returns
    -------
    angles_deg : ndarray
        长度为 n 的数组
        每个元素为最大水平主应力与 x 轴的夹角（单位：度）
        范围：[0, 180)
    """

    flat_stress = np.asarray(flat_stress)
    if flat_stress.size % 6 != 0:
        raise ValueError("输入数据长度必须是 6 的整数倍")

    n = flat_stress.size // 6
    stress = flat_stress.reshape((n, 6))

    angles_deg = np.zeros(n)

    for i in range(n):
        sxx, syy, _, sxy, _, _ = stress[i]

        # 水平应力张量
        sigma_h = np.array([[sxx, sxy*(-1)],
                             [sxy*(-1), syy]])

        # 特征分解
        eigvals, eigvecs = np.linalg.eigh(sigma_h)

        # 最大水平主应力对应的特征向量
        idx = np.argmax(eigvals)
        v = eigvecs[:, idx]

        # 与 x 轴的夹角（逆时针为正）
        angle_rad = np.arctan2(v[1], v[0])
        angle_deg = np.degrees(angle_rad)

        # 映射到 [0, 180)
        angles_deg[i] = angle_deg % 180

    return angles_deg
