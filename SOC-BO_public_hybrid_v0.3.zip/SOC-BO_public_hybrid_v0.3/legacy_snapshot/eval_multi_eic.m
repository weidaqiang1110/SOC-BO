% 向量化多约束CEI计算
function vals = eval_multi_eic(X, gp_obj, gp_cons, tol, beta, y_best)
    % 计算 EI
    [mu_o, s_o] = predict(gp_obj, X);
    z = (y_best - mu_o) ./ s_o;
    ei = (y_best - mu_o) .* normcdf(z) + s_o .* normpdf(z);
    ei(s_o < 1e-9) = 0;
    
    % 计算联合PoF， 假设各钻孔误差相互独立
       
    n_samples = size(X, 1);
   
    log_total_pof = zeros(n_samples, 1);

    n_cons = length(gp_cons);
    for b = 1:n_cons
        [mu_c, s_c] = predict(gp_cons{b}, X);
        % 计算第b个钻孔满足约束的概率
        curr_tol = tol(b);
        pof_b = normcdf((curr_tol - mu_c) ./ s_c);

        % 累乘概率
        log_total_pof = log_total_pof + log(pof_b);
    end

    % 退火
    % 将beta应用于联合分布，平滑整体梯度
    vals = ei .* exp(log_total_pof * beta);
    vals(isnan(vals)) = 0;
    % fprintf('EI %4f | PEI: %.4f\n', ei, vals);
end


