function azi = calc_azimuth_from_components(sxx, syy, txy)

n_points = length(sxx);
azi = zeros(n_points,1);
for i = 1:n_points

    % 从分量计算最大主应力方位角
    [V, D] = eig([sxx(i), txy(i); txy(i), syy(i)]);
    [~, idx] = max(diag(D));
    v = V(:, idx);

    theta = deg2rad(30);    % 模型逆时针偏离地理坐标系40度
    R= [cos(theta), sin(theta);
        -sin(theta), cos(theta)];
    v_geo = R * v;
    % Math angle (CCW from East) -> Azimuth (CW from North)
    math_rad = atan2(v_geo(2), v_geo(1));
    azi(i) = mod(90 - rad2deg(math_rad), 180);
end
end