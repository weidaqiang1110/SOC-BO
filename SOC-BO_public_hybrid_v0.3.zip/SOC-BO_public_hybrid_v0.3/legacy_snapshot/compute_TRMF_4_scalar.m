function weighted_diff = compute_TRMF_4_scalar(sim_mat, obs_mat, weights)
    % 输入: sim_mat, obs_mat 均为 [n_points x 6]
    % 列顺序: sxx, syy, szz, sxy, syz, sxz
    % 计算加权归一化 Frobenius 范数
    
    sim_mat_4 = sim_mat(:,1:4);
    obs_mat_4 = obs_mat(:,1:4);

      
    % 计算差值矩阵，然后每行乘以对应的权重
    diff_4 = sim_mat_4 - obs_mat_4;                 % [n x 4]
    weighted_diff = diff_4 .* weights(:)           % 逐元素乘法，每行缩放
end
