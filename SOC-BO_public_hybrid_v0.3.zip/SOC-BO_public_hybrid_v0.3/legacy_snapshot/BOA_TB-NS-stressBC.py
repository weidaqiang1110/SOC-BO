import itasca as it
import numpy as np
it.command ("python-reset-state false")
from stress_direction import calc_SH_azimuth_from_stress

import os
import time
import csv

step_num = 2000

flag = 1
while flag==1:
    #os.remove("calstress.csv")
    file_path = "run_simulation.txt"
    while not os.path.exists(file_path):
        time.sleep(0.5)

    boundaryPath = 'boundary.csv'
    with open(boundaryPath, encoding='utf-8') as f:
        boundaryData = np.loadtxt(f, delimiter=',',dtype = float)
        # boundaryData = np.loadtxt(f, delimiter=',',dtype = float,skiprows=1)
    print (boundaryData)
    tidu1 = (boundaryData[3]/(3800-3570)) * 1e6
    SX0 = boundaryData[1]*(-1e6)-tidu1*3800
    SX3300 = (boundaryData[1]*(-1e6) - tidu1*(3800-3300))

    tidu2 = (boundaryData[4]/(3800-3570)) * 1e6
    SY0 = boundaryData[2]*(-1e6)-tidu2*3800
    SY3300 = boundaryData[2]*(-1e6) - tidu2*(3800-3300)
    
    gravity_value = boundaryData[0] * (-1)
    sxy1 = boundaryData[5] * 1e6
    sxy2 = boundaryData[6] * 1e6

    it.command("""
        model new
        model restore '..\..\..\FLAC3D Model\K2-Hex95-para1-2.f3sav'
        ;model restore '..\..\FLAC3D Model\K2_48_para5_TB.f3sav'
        model largestrain off
               
        zone cmodel assign elastic

        zone property  young 10e9 poisson 0.26 density 2450 range group 'T3zw'
        zone property  young 10e9 poisson 0.26 density 2450 range group 'T_T3zw'

        zone property  young 25e9 poisson 0.24 density 2350 range group 'T_T3zw2'

        zone property  young 23e9 poisson 0.21 density 2950 range group 'nr3N2'
        zone property  young 23e9 poisson 0.21 density 2950 range group 'T_nr3N2'

        zone property  young 13e9 poisson 0.27 density 2200 range group 'nr1N1'
        zone property  young 13e9 poisson 0.27 density 2200 range group 'T_nr1N1'

        zone property  young 26e9 poisson 0.22 density 2400 range group 'T3z'
        zone property  young 26e9 poisson 0.22 density 2400 range group 'T_T3z'

        zone property  young 1.5e9 poisson 0.43 density 2000 range group 'Fault'
        zone property  young 1.5e9 poisson 0.43 density 2000 range group 'T_Fault'

        ; Free boundary
        ;--------------------------------------             
        zone gridpoint free velocity
        zone gridpoint initialize velocity-x 0
        zone gridpoint initialize velocity-y 0
        zone gridpoint initialize velocity-z 0
        zone face apply-remove velocity range position-x -0.1 0.1
        zone face apply-remove velocity-x range position-x -0.1 0.1
        zone face apply-remove velocity-y range position-x -0.1 0.1
        
        zone face apply-remove velocity range position-x 23999.0 24001
        zone face apply-remove velocity-x range position-x 23999.0 24001
        zone face apply-remove velocity-y range position-x 23999.0 24001
        
        zone face apply-remove velocity range position-y -0.1 0.1
        zone face apply-remove velocity-x range position-y -0.1 0.1
        zone face apply-remove velocity-y range position-y -0.1 0.1
        zone face apply-remove stress-xx range position-y -0.1 0.1
        zone face apply-remove stress-yy range position-y -0.1 0.1

        zone face apply-remove velocity range position-y 4799 4801
        zone face apply-remove velocity-x range position-y 4799 4801
        zone face apply-remove velocity-y range position-y 4799 4801
             
        ; Displacement boundaty   
        zone gridpoint fix velocity-x range position-x 23999 24001 
        zone gridpoint fix velocity-y range position-y 4799.5 4800.5
        zone gridpoint fix velocity-z range position-z 1999.9 2000.1
        
                                    
        zone face apply stress-xx {} gradient (0,0,{}) range position-x -0.1 0.1 position-z 3300 3900
        zone face apply stress-xx {} range position-x -0.1 0.1 position-z 2000 3300
               
        zone face apply stress-yy {} gradient (0,0,{}) range position-y -0.1 0.1  position-z 3300 3900
        zone face apply stress-yy {} range position-y -0.1 0.1 position-z 2000 3300
               
        zone face apply stress-xy {} range position-x -0.1 0.1
        zone face apply stress-xy {} range position-x 23999 24001
        zone face apply stress-xy {} range position-y -0.1 0.1
        zone face apply stress-xy {} range position-y 4799.5 4800.5
               
        model gravity 0 0 {}    
        """.format(SX0, tidu1, SX3300, SY0, tidu2, SY3300, sxy1, sxy1, sxy2, sxy2, gravity_value))
        
    
   
    print ("---------------")

    print ("Boundary: ",SX0, tidu1, SX3300, SY0, tidu2, SY3300, sxy1, sxy1, sxy2, sxy2, gravity_value)

    print ("-------------")

    it.fish.set("step_num",step_num)
    it.command("""
        zone initialize-stresses ratio (1.1 0.8) range group 'nr3N2' union group 'T3z' union group 'T3zw' union group 'nr1N1' union group 'T_T3zw2' union group 'T_nr3N2' union group 'T_T3z' union group 'T_T3zw' union group 'T_nr1N1'
        model history mechanical ratio
        ;model step [step_num]
        model solve
        model save 'finalCEI-it1.f3sav'
        """)


    points = [
        (20836,2209,3230),
        (20836,2209,3250),
        (20836,2209,3280),
        (10800,2175,4012), 
        (10800,2175,3834),
        (10800,2175,3784),
        (9495,1986,3594),
        (9495,1986,3644),
        (9495,1986,3675),
        (4375,3218,3812),
        (4375,3218,3862),
        (4375,3218,3893), 
        (3762,2100,3421),
        (3762,2100,3382),
        (3762,2100,3346)    
        ]
    field_names = ("stress-xx","stress-yy","stress-zz","stress-xy","stress-yz","stress-xz")
    # field_names = ("stress-xx","stress-yy","stress-zz","stress-xy")
    
    stressHist_list = []
#
    stress_output_file = "stress_tensor_output.csv"
    stress_output_file_all = "stress_tensor_output_all.csv"
        
        
    for x,y,z in points:
        local_coor = (x,y,z)
        it.command("""
            fish define local_coor_fish
            ;local_coor_fish = array(3)
            end
        """)
        it.fish.set ("local_coor_fish",local_coor)
        for field_name in field_names:
            it.fish.set ("fieldname",field_name)
            it.command("""
                fish define stress_out
                    zone.field.name = fieldname
                    ;zone.field.method.name = "inverse-distance-weighting"
                    zone.field.method.name = "constant"
                    local_stress = zone.field.get(local_coor_fish)
                end
                [stress_out]
            """)
            stress = it.fish.get("local_stress")
            stressHist_list.append(stress/(-1e6))
            stressHist_array2 = np.array(stressHist_list)
            #print(stress)
            
        
    with open (stress_output_file, mode="w") as file:  
        file.write(',' .join(map(str, stressHist_array2)) + '\n')

    with open (stress_output_file_all, mode="a") as file:  
        file.write(',' .join(map(str, stressHist_array2)) + '\n')

    # 输入指定点主应力方向
    angles = calc_SH_azimuth_from_stress(stressHist_array2)
    for i_ang, ang in enumerate(angles, start=1):
        print(f"Point {i_ang}: SH 与 x 轴夹角 = {ang:.2f}°")

    os.rename("run_simulation.txt", "simulation_completed.txt")


