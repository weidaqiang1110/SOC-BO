function [stress_mat, azimuths] = run_flac3d_simulation(x,n_point)
    % 返回应力矩阵（每行一个测点,6个应力分量）和最大主应力方向 
    
    writematrix(x, 'boundary.csv', 'Delimiter', ',');
    system('type nul>run_simulation.txt');
    fprintf('Waiting for flac3d simulation to complete ...\n')
    
    t0 = tic;
    while exist('simulation_completed.txt','file') == 0
        pause(1);
        if toc(t0) > 3600
            error('FLAC3D simulation timeout (.1 hour).');
        end
    end

    fprintf('The FLAC 3D simulation results have been read\n')
    
    % 应力输出形式：（单一测点一整行（列）的形式）
    stress_cal = csvread("stress_tensor_output.csv");
    stress_tensors = reshape(stress_cal',[],n_point)';
    stress_tensors(:,4) = stress_tensors(:,4) * -1;
    stress_mat = stress_tensors;  % 提取前4个应力分量
    azimuths = calc_azimuth_from_components(stress_tensors(:,1),...
        stress_tensors(:,2), stress_tensors(:,4));
    delete("simulation_completed.txt");
end