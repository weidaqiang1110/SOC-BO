import sys
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "flac3d_python"))
from socbo_flac3d.constants import (  # noqa: E402
    AZIMUTH_CONVENTION,
    PARAMETER_NAMES,
    PARAMETER_UNITS,
    PROTOCOL_NAME,
    SCHEMA_VERSION,
    STRESS_COMPONENTS,
    STRESS_SIGN_CONVENTION,
    STRESS_UNIT,
)
from socbo_flac3d.mock_adapter import MockAdapter  # noqa: E402
from socbo_flac3d.protocol import atomic_write_json, atomic_write_text, read_json, read_stress_csv  # noqa: E402
from socbo_flac3d.worker import FileQueueWorker  # noqa: E402


def make_request(run_id):
    return {
        "protocol": PROTOCOL_NAME,
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "software": {"matlab": "R2022b", "flac3d": "7.0"},
        "model_x_azimuth_deg": 60.0,
        "parameters": {
            "names": PARAMETER_NAMES,
            "units": PARAMETER_UNITS,
            "values": [9.8, -10, -8, -6, -5, 0.5],
        },
        "stress_sign_convention": STRESS_SIGN_CONVENTION,
        "stress_output_unit": STRESS_UNIT,
        "stress_component_order": STRESS_COMPONENTS,
        "azimuth_convention": AZIMUTH_CONVENTION,
        "expected_point_ids": ["P02", "P01"],
        "expected_n_points": 2,
        "linear_profile": {"z_top_m": 3800.0, "z_bottom_m": 2000.0, "clip": True},
        "model_config_hash": "a" * 64,
    }


def queue_task(root, run_id, cancel=False):
    task = root / "queued" / run_id
    task.mkdir(parents=True)
    atomic_write_json(task / "request.json", make_request(run_id))
    atomic_write_text(task / "READY", run_id + "\n")
    if cancel:
        atomic_write_text(task / "CANCEL", "test cancellation\n")


class WorkerQueueTests(unittest.TestCase):
    def test_completed_task_has_ids_native_stress_and_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in ["queued", "running", "completed", "failed", "cancelled", "workers"]:
                (root / name).mkdir(parents=True, exist_ok=True)
            queue_task(root, "task-ok")
            worker = FileQueueWorker(root, MockAdapter(), 0.05, 1.0, 2)
            worker.start()
            try:
                self.assertTrue(worker.run_once())
            finally:
                worker.stop()
            completed = root / "completed" / "task-ok"
            self.assertTrue(completed.is_dir())
            result = read_json(completed / "result.json")
            self.assertEqual(result["status"], "succeeded")
            self.assertEqual(result["stress_sign_convention"], STRESS_SIGN_CONVENTION)
            ids, stress = read_stress_csv(completed / "stress.csv")
            self.assertEqual(ids, ["P02", "P01"])
            self.assertTrue((stress[:, :3] < 0.0).all())

    def test_queued_cancellation_moves_to_cancelled(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in ["queued", "running", "completed", "failed", "cancelled", "workers"]:
                (root / name).mkdir(parents=True, exist_ok=True)
            queue_task(root, "task-cancel", cancel=True)
            worker = FileQueueWorker(root, MockAdapter(), 0.05, 1.0, 2)
            worker.start()
            try:
                self.assertFalse(worker.run_once())
            finally:
                worker.stop()
            self.assertTrue((root / "cancelled" / "task-cancel").is_dir())


if __name__ == "__main__":
    unittest.main()
