import sys
from pathlib import Path
import unittest
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "flac3d_python"))
from socbo_flac3d.stress_orientation import (  # noqa: E402
    hf_to_model_observables_pa,
    sh_from_flac_stress_pa,
    signed_axial_difference,
)


class StressOrientationTests(unittest.TestCase):
    def test_x_east_native_sign(self):
        stress = np.array([[-20e6, -10e6, -5e6, 0, 0, 0]], dtype=float)
        SH, Sh, az = sh_from_flac_stress_pa(stress, 90.0)
        np.testing.assert_allclose([SH[0], Sh[0], az[0]], [20e6, 10e6, 90], atol=1e-6)

    def test_x_north_native_sign(self):
        stress = np.array([[-20e6, -10e6, -5e6, 0, 0, 0]], dtype=float)
        _, _, az = sh_from_flac_stress_pa(stress, 0.0)
        self.assertAlmostEqual(float(az[0]), 0.0, places=12)

    def test_axial_wrap_and_sign(self):
        result = signed_axial_difference(
            np.array([179, 10, 320]), np.array([1, 170, 300])
        )
        np.testing.assert_allclose(result, [-2, 20, 20], atol=1e-12)

    def test_hf_conversion_round_trip_native_pa(self):
        SH = np.array([20.0, 30.0, 18.0])
        Sh = np.array([10.0, 12.0, 9.0])
        Sv = np.array([15.0, 20.0, 11.0])
        az = np.array([60.0, 310.0, 5.0])
        alpha = 60.0
        obs = hf_to_model_observables_pa(SH, Sh, Sv, az, alpha)
        stress6 = np.column_stack(
            [obs[:, 0], obs[:, 1], obs[:, 3], obs[:, 2], np.zeros((3, 2))]
        )
        SH2, Sh2, az2 = sh_from_flac_stress_pa(stress6, alpha)
        np.testing.assert_allclose(SH2 / 1e6, SH, atol=1e-10)
        np.testing.assert_allclose(Sh2 / 1e6, Sh, atol=1e-10)
        np.testing.assert_allclose(signed_axial_difference(az2, az), 0.0, atol=1e-10)
        self.assertTrue(np.all(obs[:, [0, 1, 3]] <= 0.0))


if __name__ == "__main__":
    unittest.main()
