import sys
from pathlib import Path
import tempfile
import unittest
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "flac3d_python"))
from socbo_flac3d.constants import (  # noqa: E402
    AZIMUTH_CONVENTION,
    PARAMETER_NAMES,
    PARAMETER_UNITS,
    PROTOCOL_NAME,
    SCHEMA_VERSION,
    STRESS_COMPONENTS,
    STRESS_SIGN_CONVENTION,
    STRESS_UNIT,
)
from socbo_flac3d.protocol import (  # noqa: E402
    ForwardResult,
    read_stress_csv,
    sha256_file,
    validate_request,
    write_stress_csv,
)


def valid_request(run_id="run-1"):
    return {
        "protocol": PROTOCOL_NAME,
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "software": {"matlab": "R2022b", "flac3d": "7.0"},
        "model_x_azimuth_deg": 60.0,
        "parameters": {
            "names": PARAMETER_NAMES,
            "units": PARAMETER_UNITS,
            "values": [9.8, -10, -8, -6, -5, 0.5],
        },
        "stress_sign_convention": STRESS_SIGN_CONVENTION,
        "stress_output_unit": STRESS_UNIT,
        "stress_component_order": STRESS_COMPONENTS,
        "azimuth_convention": AZIMUTH_CONVENTION,
        "expected_point_ids": ["P01", "P02"],
        "expected_n_points": 2,
        "linear_profile": {"z_top_m": 3800.0, "z_bottom_m": 2000.0, "clip": True},
        "model_config_hash": "a" * 64,
    }


class ProtocolTests(unittest.TestCase):
    def test_request_validation(self):
        normalized = validate_request(valid_request())
        self.assertEqual(normalized["parameters"]["values"][1], -10.0)
        broken = valid_request()
        broken["stress_sign_convention"] = "compression_positive"
        with self.assertRaises(ValueError):
            validate_request(broken)

    def test_stress_csv_round_trip_and_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "stress.csv"
            stress = np.array([[-1e6, -2e6, -3e6, 4e5, -5e5, 6e5]])
            write_stress_csv(path, ["P01"], stress)
            ids, actual = read_stress_csv(path)
            self.assertEqual(ids, ["P01"])
            np.testing.assert_allclose(actual, stress)
            self.assertEqual(len(sha256_file(path)), 64)

    def test_forward_result_rejects_unconverged(self):
        result = ForwardResult(["P01"], np.zeros((1, 6)), converged=False)
        with self.assertRaises(ValueError):
            result.validate()


if __name__ == "__main__":
    unittest.main()
