import sys
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "flac3d_python"))
from socbo_flac3d.model_hash import hash_files  # noqa: E402


class ModelHashTests(unittest.TestCase):
    def test_hash_is_order_independent_and_content_sensitive(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            a = root / "a.txt"
            b = root / "b.txt"
            a.write_text("alpha", encoding="utf-8")
            b.write_text("beta", encoding="utf-8")
            first = hash_files([a, b], root=root)
            second = hash_files([b, a], root=root)
            self.assertEqual(first, second)
            b.write_text("changed", encoding="utf-8")
            self.assertNotEqual(first, hash_files([a, b], root=root))


if __name__ == "__main__":
    unittest.main()
