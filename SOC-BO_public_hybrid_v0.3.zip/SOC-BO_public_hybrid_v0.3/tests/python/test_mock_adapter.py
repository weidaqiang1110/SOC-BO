import sys
from pathlib import Path
import unittest
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "flac3d_python"))
from socbo_flac3d.mock_adapter import MockAdapter  # noqa: E402


def request():
    return {
        "parameters": {"values": [9.8, -10.0, -8.0, -6.0, -5.0, 1.0]},
        "expected_point_ids": ["P01", "P02", "P03", "P04"],
    }


class MockAdapterTests(unittest.TestCase):
    def test_shape_sign_and_finiteness(self):
        out = MockAdapter().evaluate(request(), lambda: False, lambda: None)
        out.validate()
        self.assertEqual(out.stress_pa.shape, (4, 6))
        self.assertTrue(np.isfinite(out.stress_pa).all())
        self.assertTrue(np.all(out.stress_pa[:, :3] < 0.0))

    def test_cancel_is_honored(self):
        with self.assertRaises(RuntimeError):
            MockAdapter().evaluate(request(), lambda: True, lambda: None)


if __name__ == "__main__":
    unittest.main()
