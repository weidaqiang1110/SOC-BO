import sys
from pathlib import Path
import unittest
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "flac3d_python"))
from socbo_flac3d.loading import (  # noqa: E402
    SixParameterLoading,
    flac_base_gradient_pa,
    flac_native_profile_mpa,
    normalized_depth,
)


class LoadingTests(unittest.TestCase):
    def test_six_parameter_validation(self):
        load = SixParameterLoading.from_array([9.8, -10, -8, -6, -5, 1])
        self.assertEqual(load.gravity_m_s2, 9.8)
        with self.assertRaises(ValueError):
            SixParameterLoading.from_array([9.8, 1, 2])

    def test_native_profile_endpoints(self):
        z_top, z_bottom = 3800.0, 2000.0
        z = np.array([z_top, (z_top + z_bottom) / 2, z_bottom])
        np.testing.assert_allclose(normalized_depth(z, z_top, z_bottom), [0, 0.5, 1])
        np.testing.assert_allclose(
            flac_native_profile_mpa(z, -10, -8, z_top, z_bottom),
            [-10, -14, -18],
        )

    def test_flac_base_gradient_matches_native_profile(self):
        z_top, z_bottom = 3800.0, 2000.0
        base, grad = flac_base_gradient_pa(-10.0, -8.0, z_top, z_bottom)
        for z in [z_top, 3000.0, z_bottom]:
            solver_pa = base + grad * z
            expected_pa = 1.0e6 * flac_native_profile_mpa(
                z, -10.0, -8.0, z_top, z_bottom
            )
            self.assertAlmostEqual(float(solver_pa), float(expected_pa), places=6)


if __name__ == "__main__":
    unittest.main()
