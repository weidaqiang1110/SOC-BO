% Solver-independent MATLAB R2022b tests for SOC-BO v0.3.
root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(root,'matlab'));

% Native FLAC3D HF transform and round-trip orientation.
SH = [20;30;18]; Sh = [10;12;9]; Sv = [15;20;11];
az = [60;310;5]; alpha = 60;
obs_pa = socbo.hf_to_model_observables(SH,Sh,Sv,az,alpha);
stress6_pa = [obs_pa(:,1),obs_pa(:,2),obs_pa(:,4),obs_pa(:,3),zeros(3,2)];
[SH2_pa,Sh2_pa,az2] = socbo.sh_from_stress(stress6_pa,alpha);
assert(max(abs(SH2_pa/1e6-SH))<1e-9);
assert(max(abs(Sh2_pa/1e6-Sh))<1e-9);
assert(max(abs(socbo.signed_axial_difference(az2,az)))<1e-9);
assert(all(obs_pa(:,[1,2,4])<=0,'all'));

% Axial wrap and sign.
d = socbo.signed_axial_difference([179;10;320],[1;170;300]);
assert(max(abs(d-[-2;20;20]))<1e-12);

% Point-normalized objective uses native signed Pa tensors.
w = [1;0.85;1]; eta_pa = 1;
[J,p,sim_obs] = socbo.stress_objective(stress6_pa,obs_pa,w,eta_pa);
assert(abs(J)<1e-14 && max(abs(p))<1e-14);
assert(isequal(sim_obs,obs_pa));

% Signed borehole diagnostics.
m = socbo.borehole_orientation_metrics([10;20;30;50],[12;18;40;45], ...
    [1;1;2;2],[1;1;1;1],2);
assert(max(abs(m.signed_mean_deg-[-0, -2.5]))<1e-12); % [-2,+2] and [-10,+5]
assert(max(abs(m.rmse_deg-[2,sqrt(62.5)]))<1e-12);

% Native signed linear-profile coefficients.
z_top = 3800; z_bottom = 2000; U = -10; L = -8;
% Equivalent formula from Python helper:
dz = z_top-z_bottom;
base = 1e6*(U+L*z_top/dz);
grad = -1e6*L/dz;
for z = [z_top,3000,z_bottom]
    xi = (z_top-z)/dz;
    expected = 1e6*(U+L*xi);
    assert(abs((base+grad*z)-expected)<1e-5);
end

fprintf('All solver-independent MATLAB tests passed.\n');
