# Changelog

## v0.3.0 — persistent queue and native FLAC3D stress convention

- added persistent task directories, JSON schema, worker heartbeat, task lease,
  stale recovery, cancellation, and finite retries;
- added point-ID-bearing stress output, explicit result metadata, model/config
  hash matching, and SHA-256 verification;
- retained native FLAC3D stress signs and Pa throughout forward exchange and
  objective calculations;
- converted positive HF magnitudes to negative native tensor components;
- selected SH from the smallest horizontal eigenvalue under FLAC3D signs;
- removed all solver-to-compression-positive and isolated shear sign flips;
- updated linear boundary-profile coefficients for native signed parameters;
- added queue, cancellation, checksum, schema, sign, and round-trip tests.

## v0.2.0 — manuscript-contract revision

- fixed the inverse vector to six parameters and retained gravity as an inverse
  variable;
- added configurable linear profiles, HF coordinate transformation, separate
  weights, signed diagnostics, and particle-swarm acquisition maximization.

## v0.1.0 — initial audit draft

- preserved the uploaded prototype and modularized the MATLAB/Python layers.
