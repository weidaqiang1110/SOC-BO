# SOC-BO hybrid implementation v0.3

This repository contains the public algorithmic implementation of the
stress-orientation-constrained Bayesian optimization (SOC-BO) workflow used
with MATLAB R2022b and FLAC3D 7.0. The confidential engineering model and raw
field measurements are intentionally excluded.

## What changed in v0.3

- MATLAB and FLAC3D now communicate through a persistent task-directory queue
  with explicit JSON schema, worker heartbeat, task lease, stale-task recovery,
  cancellation, finite retry count, result metadata, point IDs, and SHA-256
  verification.
- All tensor stresses retain FLAC3D's native convention throughout the forward
  interface and objective calculation: **tension positive, compression
  negative**. The solver output is exchanged in Pa with component order
  `[sxx, syy, szz, sxy, syz, sxz]`; there is no tensor-wide or shear-only sign
  reversal.
- Hydraulic-fracturing `SH`, `Sh`, and `Sv` inputs remain conventional positive
  compression magnitudes in MPa. They are converted once to a native signed
  model-coordinate tensor in Pa.
- `SH` orientation is recovered from the eigenvector associated with the
  smallest horizontal stress eigenvalue, because this is the most compressive
  direction under FLAC3D signs.

## Six-parameter contract

```text
[G, SX_uniform, SY_uniform, SX_linear, SY_linear, SXY]
```

`G` is a positive gravity magnitude in m/s². All stress parameters are native
signed FLAC3D tensor quantities in MPa. For this compressive geostress problem,
normal uniform and downward linear-increment terms are ordinarily negative;
`SXY` may be positive or negative according to the model coordinate system.

## Repository layout

```text
matlab/                      MATLAB SOC-BO implementation
flac3d_python/socbo_flac3d/ FLAC3D worker, protocol, and adapter template
tests/matlab/               solver-independent MATLAB tests
tests/python/               protocol, sign, queue, and numerical tests
docs/                       mathematical and integration specifications
legacy_snapshot/            unchanged uploaded prototype for traceability
```

## Persistent queue layout

```text
exchange/
├── queued/
├── running/
├── completed/
├── failed/
├── cancelled/
└── workers/
```

Each task is an individual UUID directory. MATLAB publishes a complete queued
folder atomically. A worker claims it by moving the folder to `running/`,
refreshes a lease while FLAC3D is solving, and finally moves it to a terminal
state. `stress.csv` includes `point_id`, native signed Pa components, and a
SHA-256 digest recorded in `result.json`.

See `docs/FILE_QUEUE_PROTOCOL.md` for the exact contract.

## Private setup

1. Copy `matlab/config/project_config_template.m` to a private configuration.
2. Fill in parameter bounds, model-X geographic azimuth, linear-profile
   elevations, borehole tolerances, HF data path, and a non-placeholder
   `model_config_hash`.
3. Copy `project_adapter_template.py` outside the repository and implement the
   confidential model restore, boundary groups, solve criterion, and point
   extraction.
4. Ensure that the same SHA-256 model/config identifier is returned by the
   private Python adapter and stored in the MATLAB configuration. The helper
   `tools/compute_model_hash.py` can hash a private save file, adapter, boundary
   manifest, and point map without exposing them.
5. Keep the exchange directory on one local filesystem. Avoid OneDrive and
   unstable network shares because atomic directory moves and leases are part
   of the protocol.

## Starting the FLAC3D worker

Inside the FLAC3D 7.0 Python environment, add `flac3d_python` and the private
adapter directory to `sys.path`, then set:

```text
SOCBO_EXCHANGE_DIR=<absolute local exchange directory>
SOCBO_ADAPTER=<private_module>:<AdapterClass>
SOCBO_HEARTBEAT_SECONDS=5
SOCBO_LEASE_SECONDS=60
SOCBO_MAX_ATTEMPTS=2
```

Run:

```python
from socbo_flac3d.worker import run_forever
run_forever()
```

MATLAB performs a compatible-worker preflight before publishing any candidate.

## Running MATLAB

```matlab
addpath('matlab');
results = main_socbo(@project_config_private);
```

## Tests

Python tests:

```bash
python -m unittest discover -s tests/python -v
```

MATLAB R2022b tests:

```matlab
run('tests/matlab/run_all_tests.m')
```

The public tests do not reproduce the confidential engineering case. Before a
release is tagged, the author must also run one private MATLAB–FLAC3D end-to-end
smoke test and verify the applied boundary signs and extracted tensor order in
FLAC3D 7.0.

## Reproducibility boundary

The source code, mathematical definitions, task protocol, and non-project tests
are public. The project-specific FLAC3D model, geological geometry, observation
coordinates, and raw in-situ stress measurements remain restricted. See
`docs/REPRODUCIBILITY_SCOPE.md`.
